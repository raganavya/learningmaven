<#
    .SYNOPSIS
        This script copies the list of blob containers, directories, and blobs from ADLS storage account to another by using a SAS token.
    .DESCRIPTION
           
        This powershell script copies all containers and blobs listed in CSV file from one storage account to another storage account. This command is using the user assigned managed identity,
        which will retrieve the SAS token from the Azure Key Vault. Then, it sync all the containers from one storage account to another. The user assigned managed identity
        must be tied to the Azure VM where you are running this script from, and should have atleast Storage Blob Data Reader RBAC role.
    #>


# Set start time
$StartTime = Get-Date

Write-Host "*********************************"
Write-Host "Script execution start time: " $StartTime

$ErrorActionPreference = 'stop'
# ----------------------------------------------------------Enforce TLS 1.2 Protocol ------------------------------------------------------------------------------------------------#

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ----------------------------------------------------------Authenticate with Azure using AZ Copy -----------------------------------------------------------------------------------#
# Download AZCopy and make a alias from the downloaded exe file
# Make a alias from the downloaded azcopy.exe file
if ((Test-Path Alias:azcopy) -eq $false) {New-alias -Name azcopy -value "C:\azcopy_windows_amd64_10.10.0\azcopy_windows_amd64_10.10.0\azcopy.exe"}

# Get the ClientID of User Assigned Managed Identity
    $ClientID = "059f02b1-cdcd-4afd-a35f-ebda165b7b0a"
# This URI is static to make a call to Azure using MSI
    $URI = 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net'
# Get the SubscriptionId
    $subscription = "1e4d857b-9767-4d94-84cc-da027d4371c8"

# Login to Azure using User Assigned Managed Identity's Client ID --> Ref: https://docs.microsoft.com/en-us/azure/storage/common/storage-use-azcopy-authorize-azure-active-directory
    azcopy login --identity --identity-client-id $ClientID

# ----------------------------------------------------------GET TOKEN USING MSI------------------------------------------------------------------------------------------------------#

# Make an API call to OAuth Token Endpoint to get the token. The endpoint 169.254.169.254 is only routable within azure and azure resources
    $Response = Invoke-RestMethod -Uri $URI -Method GET -Headers @{Metadata="true"}

# Extract the Access token from the response
    $KeyVaultToken = $Response.access_token

# ----------Connect to Azure to Enable option "Allow Storage Account Key"
    Connect-AzAccount -Identity -Subscription $subscription

#-----------------------------------------------------------Storage Account Information----------------------------------------------------------------------------------------------#

    $SourceStorageAccount = "dacdatalake01"
    $SourceStorageKey = (Invoke-RestMethod -Uri https://DACKeyVault.vault.azure.net/secrets/dacdatalake01-sas-token/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value

    $DestinationStorageAccount = "dacbackups01"
    $DestStorageKey = (Invoke-RestMethod -Uri https://DACKeyVault.vault.azure.net/secrets/dacbackups01-sas-token/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value

#---------------------------------------------------------Getting Containers from the text file list -------------------------------------------------------------------------------------#

 $path = "C:\work\full"
 $outputFileName = "azcopy_full_output"
 # Providing the container list of raw-covid19,raw-archive, raw-covid19/SocialImpact_Dashboard
 $Name=Get-Content -Path "C:\work\full\list.txt"
 
 foreach($contName in $Name)
 {
    $FileName=get-childitem -Path $path\*$contName.csv
    $AllContainers = Get-Content -Path $FileName
    Write-Host "*********************************"
    Write-Host "The name of the container list file :"  $FileName 
    Write-Host "List of containers:  " 
    Format-List -InputObject $AllContainers
    Write-Host "*********************************"
    
    $output = foreach ($container in $AllContainers)
    {
        if($contName -eq "raw-covid19-SocialImpact_Dashboard")
        {
            $contName="raw-covid19/SocialImpact_Dashboard"
        
        }
        
        $source = "https://dacdatalake01.blob.core.windows.net/" + "$contName/" + "$container$SourceStorageKey"
        $Destination = "https://dacbackups01.blob.core.windows.net/dac-datalake-compliance-backup/2021/" + "$contName" + "$DestStorageKey"
    # Coping the containers with azcopy
        azcopy copy $Source $Destination --recursive=true --log-level INFO 
        Write-Host "AzCopy completed for the container :" $container
    } 
    $output | Out-File "C:\temp\dac-all\$outputFileName-$(get-date -f yyyy_MM_dd_hh_mm_ss).txt"
 }
    
    $EndTime = Get-Date
    $Duration = New-TimeSpan -Start $StartTime -End $EndTime

    $Hour = switch ($Duration.Hours)
    {
        #0 { $null; break }
        1 { "{0} hour," -f $Duration.Hours; break }
        Default { "{0} hours," -f $Duration.Hours }
    }

    $Minute = switch ($Duration.Minutes)
    {
        #0 { $null; break }
        1 { "{0} minute," -f $Duration.Minutes; break }
        Default { "{0} minutes," -f $Duration.Minutes }
    }

    $Second = switch ($Duration.Seconds)
    {
        #0 { $null; break }
        1 { "{0} second" -f $Duration.Seconds; break }
        Default { "{0} seconds" -f $Duration.Seconds }
    }

    Write-Host "*********************************"

    Write-Host "The script execution took " $Hour $Minute $Second
    Write-Host "Script execution completed"

    Write-Host "*********************************"


  




  