# Define Variables
$SubscriptionId = "<subId>"
$credential = Connect-AzAccount
$context = Set-AzContext -SubscriptionId "<subid>"
$ResourceGroupName = "dac-datalake-rg"
$StorageAccountName = "dacdatalake01"
$IPAddressToWhitelist = "<IP ADDRESS>" # ---> Enter the IP address to whitelist here

# Whitelist the IP address
Add-AzStorageAccountNetworkRule -ResourceGroupName $ResourceGroupName -AccountName $StorageAccountName -IPAddressOrRange $IPAddressToWhitelist