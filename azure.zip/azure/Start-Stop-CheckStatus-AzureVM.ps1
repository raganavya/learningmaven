﻿# Connect to Azure
Connect-AzAccount

# Create a new context for the Prod Subscription

Get-AzSubscription -SubscriptionName 'NSWDAC_PROD' | Set-AzContext -Name 'MyProdContext'

# Create a new context for the NonProd Subscription

Get-AzSubscription -SubscriptionName 'NSWDAC_NONPROD' | Set-AzContext -Name 'MyNonProdContext'

# Change the active Azure context

Set-AzContext -Context $(Get-AzContext -Name "MyProdContext") # Set a context with an inline Azure context object

# Check the status of existing VM

Get-AzVM -Name "npdac-storage-account-script-runner02" -Status

# Start the Azure VM

$VMName = "npdac-storage-account-script-runner02"
Start-AzVM -ResourceGroupName "npdac-datalake-rg" -Name $VMName

# Stop the Azure VM

$VMName = "npdac-storage-account-script-runner02"
Stop-AzVM -ResourceGroupName "npdac-datalake-rg" -Name $VMName

