    select   gu.grantee_name as user_name,
         ro.name snowflake_role,
         gr.granted_on as snowflake_object_type,
         gr.name as snowflake_object_name,
         gr.privilege,
--         gu.deleted_on,
--         gu.created_on,
         us.disabled
from snowflake.account_usage.roles ro
inner join snowflake.account_usage.grants_to_users gu
   on gu.role = ro.name
inner join snowflake.account_usage.grants_to_roles gr
    on ro.name = gr.grantee_name
inner join   snowflake.account_usage.users us
    on us.name = gu.grantee_name
where  1= 1
and   gr.granted_on = 'DATABASE'
and   gu.deleted_on is null
and   us.disabled = 'false'
-- and    gu.grantee_name = 'SIDDHANT.MALIK1@DAC.NSW.GOV.AU'
order by  gu.grantee_name;
