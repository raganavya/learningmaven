#!/bin/bash
echo "Cleaning up Tableau Server Log Files..."

#cleans up all log files older than 14 days old

tsm maintenance cleanup -l --log-files-retention 14