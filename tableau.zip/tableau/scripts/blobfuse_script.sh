#!/bin/bash
sudo blobfuse /data/dac-tableau-backup --tmp-path=/mnt/resource/blobfusetmp --config-file=/data/fuse_connection.cfg -o attr_timeout=240 -o entry_timeout=240 -o negative_timeout=120