#!/bin/bash
####################################################################################################################################

# This script takes the backup of Tableau server and copies it to the ADLS container named "npdacbackupblob", along with log files and if it failes then send email
# Backup Tableau Server Data [includes data extract files and the Tableau PostgreSQL database, which contains workbook and user metadata]

####################################################################################################################################


#VARIABLES SECTION
# Set some variables - you should change these to match your own environment

# Set the date how we want it
DATE="$(date +%m-%d-%Y)"
# Grab the current datetime for timestamping the log entries
TIMESTAMP="$(date +%m-%d-%Y_%H-%M-%S)"
# Do you want to copy your backups to another location after completion?
copy_backup="yes"
# If yes to above, where do you want to copy them?
external_backup_path="/data/dac-tableau-backup/"
# How many days do you want to keep old backup files for?
backup_days="14"
# What do you want to name your backup files? (will automatically append current date to this filename)
backup_name="dac-tableau-server-backup"
# Path of the log file
Log_dir="/data/scripts/logs"
# Name of the log file
LOG_FILE="${Log_dir}/dac-tableau-server-backup-log-$TIMESTAMP.log"

# END OF VARIABLES SECTION

# Exit on error
set -e
##################################

# Function to write to the Log file

###################################

write_log()
{
  while read -r text
  do
      LOGTIME=`date "+%Y-%m-%d %H:%M:%S"`
      # If log file is not defined, just echo the output
      if [ "$LOG_FILE" == "" ]; then
    echo $LOGTIME": $text";
      else
      LOG=$LOG_FILE
    touch $LOG
        if [ ! -f $LOG ]; then echo "ERROR!! Cannot create log file $LOG. Exiting."; exit 1; fi
    echo $LOGTIME": $text" | tee -a $LOG;
      fi
  done
}

# BACKUP SECTION

# get the path to the backups folder
backup_path="$(tsm configuration get -k basefilepath.backuprestore)"
echo $TIMESTAMP "The path for storing backups is $backup_path" | write_log

# count the number of backup files eligible for deletion and output
echo $TIMESTAMP "Cleaning up old backups..." | write_log
lines=$(find $external_backup_path -type f -regex '.*.\(tsbak\|json\)' -mtime +$backup_days | wc -l)
if [ $lines -eq 0 ]; then
        echo $TIMESTAMP $lines old backups found, skipping..
        else echo  $TIMESTAMP $lines old backups found, deleting...
                #remove backup files older than N days
                find $external_backup_path -type f -regex '.*.\(tsbak\|json\)' -mtime +$backup_days -exec rm -f {} \;
fi

#export current settings
echo $TIMESTAMP "Exporting current settings..."         | write_log
tsm settings export -f $backup_path/settings-$DATE.json
#create current backup
echo $TIMESTAMP "Backup up Tableau Server data..."      | write_log
tsm maintenance backup -f $backup_name -d

#copy backups to different location (optional)- It is copying the backup file from /var/opt/tableau/tableau_server/data/tabsvc/files/backups to "/home/dacadmin/npdac-tableau-container-backupdrive"
if [ "$copy_backup" == "yes" ];
        then
        echo $TIMESTAMP "Copying backup and settings to remote share"
        cp $backup_path/* $external_backup_path/
fi

# END OF BACKUP SECTION

# Cleanup backup from /var/opt/tableau/tableau_server/data/tabsvc/files/backups or /data/temp_backups/ if configured using "tsm configuration set -k basefilepath.backuprestore -v "/data/temp_backups" command externally

rm $backup_path/*
echo "Removed backups from temporary location: $backup_path"

# copy log files to $external_backup_path
cp $LOG_FILE $external_backup_path | write_log

#Email Notification
if [ "$?" == 0 ]; then
        echo "Backup Process was Successful. A new backup file $external_backup_path has been created" | mailx -s "Tableau Server Backup Status Successful" jaspreet.singh@customerservice.nsw.gov.au
else
        echo "Backup Process Failed. Please contact DAC Support Team" | mailx -s "Tableau Server Backup Failed" support@dacsupport.zendesk.com
        exit 1
fi

# END OF SCRIPT
echo $TIMESTAMP "Backup completed & $backup_name copied to ADLS" | write_log

#END

#Backup Tableau Server Data [includes data extract files and the Tableau PostgreSQL database, which contains workbook and user metadata]
#Reference: https://github.com/til-jmac/tableau-server-housekeeping/blob/master/linux/tableau-server-backup.bash
