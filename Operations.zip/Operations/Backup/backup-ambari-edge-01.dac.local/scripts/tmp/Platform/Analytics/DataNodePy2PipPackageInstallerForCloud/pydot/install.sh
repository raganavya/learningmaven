#!/bin/sh
ansible-playbook -i ./scripts/hosts ./scripts/pydot-install.sh
