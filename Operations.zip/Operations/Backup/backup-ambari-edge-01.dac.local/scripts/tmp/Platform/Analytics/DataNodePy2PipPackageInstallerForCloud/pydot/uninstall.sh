#!/bin/sh
ansible-playbook -i ./scripts/hosts ./scripts/pydot-uninstall.sh
