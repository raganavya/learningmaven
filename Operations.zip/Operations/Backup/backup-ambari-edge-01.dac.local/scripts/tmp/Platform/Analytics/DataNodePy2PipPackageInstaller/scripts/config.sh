#!/bin/bash

_THIS_DIR="$(cd "$(dirname "$0")"; pwd)"
HOST_FILE="${_THIS_DIR}/../host_lists/dace2_data_node_addresses.txt"
