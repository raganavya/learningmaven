#!/bin/sh

pip uninstall -y pydot
# yum remove -y graphviz
# yum remove -y python-pip
# yum remove -y epel-release

