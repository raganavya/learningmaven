#!/bin/sh

yum install -y epel-release
yum install -y python-pip
yum install -y graphviz
pip install pydot

