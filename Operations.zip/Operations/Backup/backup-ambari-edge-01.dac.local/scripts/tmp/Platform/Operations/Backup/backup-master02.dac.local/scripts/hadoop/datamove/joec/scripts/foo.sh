#!/bin/bash

/usr/bin/ssh backup-master01 'mkdir -p /tmp/foobarfish'

