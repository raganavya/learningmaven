EMAILADDRESS="timothy.hayes@treasury.nsw.gov.au"
i=1

if [ "$i" -eq 1 ]; then
	(( i = i + 1 ))

        (
		echo To: $EMAILADDRESS
                echo Subject: "Error"
                echo "Mime-Version: 1.0"
                echo 'Content-Type: multipart/mixed; boundary="GvXjxJ+pjyke8COw"'
                echo ""
                echo "--GvXjxJ+pjyke8COw"
                echo "Content-Type: text/html"
                echo "Content-Disposition: inline"
                echo ""
                echo "Zipping failed. Check log file under /analytics/log for more information."
                echo "--GvXjxJ+pjyke8COw"
                echo "Content-Type: application/text/html"
                echo "Content-Transfer-Encoding: base64"
                echo ""
    	) | /usr/sbin/sendmail -t
fi
