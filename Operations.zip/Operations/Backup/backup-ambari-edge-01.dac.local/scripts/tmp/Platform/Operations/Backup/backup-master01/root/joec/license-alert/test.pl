#!/usr/bin/perl
#
use strict;
use lib '.';
use POSIX qw/difftime mktime strftime/;
use Text::CSV;

sub day;
sub hh;
sub mm;
sub ss;

my $csv = Text::CSV->new({ sep_char => ',' });

my $cfile = 'license-data.csv';
my $token = 'token=AoGhFYvmHyhBZiXzXes9XOKEasgnnSbGks5bu_cCwA%3D%3D';
my $giturl = "https://raw.githubusercontent.com/NSWDAC/Platform/master/Operations/License%20Alert";
my $cmd = "curl -Os $giturl/$cfile?$token";
my $offset = 10; # hours diff from system
my $diff;
my $html;
my $text;
my $now = now();
my $NOW = strftime('%Y-%m-%d %H:%M:%S', localtime($now));
my $to = 'Joe.Chiu@treasury.nsw.gov.au';
# my $to = 'Indu.Neelakandan@treasury.nsw.gov.au,Joe.Chiu@treasury.nsw.gov.au';
my $from = 'Joe.Chiu@treasury.nsw.gov.au';
my $subject = "Just a test sample";
my @th = ( "SOFTWARE", "SERVER", "EXPIRYDATE", "DAY", "HOUR", "MIN", "SEC", "STATUS", "NOTE" );

system $cmd;
rename "$cfile?$token", $cfile;
unlink "$cfile?$token";
if (!-e $cfile) {
        exit mailer("$cfile not exists...");
}

$html .= "<b>License Expiration Report: generated at $NOW</b>\n";
$text .= "License Expiration Report: generated at $NOW\n";
$html .= "<table border=0 cellspacing=0 cellpadding=0 width=960 bgcolor='#000000'>\n<tr><td>\n";
$html .= "<table border=0 cellspacing=1 cellpadding=6 width=100% align=center>\n";
$html .= qq(<tr style="color:white"><td><b>).join('</b></td><td><b>',@th)."</b></td></tr>\n";

open my $fh, "<:encoding(utf8)", $cfile or die "$cfile: $!";
R: while ( my $r = $csv->getline( $fh ) ) {

	# print join("--", @$r),"\n";
	my ($app, $env, $ip, $host, $exp, $note) = @$r;
        $exp =~ /\//g || next R;
        my @d = split /\//, $exp;
        my $then = mktime(0,0,0,$d[0],$d[1]-1,$d[2]-1900);

        $diff = difftime($then, $now);

        my $msg = sprintf "%-36s%-36s%10s%12s%12s%12s%12s", "$app($env)", "$host($ip)", $exp, day, hh, mm, ss;
	my @td = ("$app($env)", "$host($ip)", $exp, day, hh, mm, ss);
	my $bg = "#ffffff";
        if ($diff > 0) {
                if (day() < 1) {
			$bg = "#AED6F1";
                        push @td, "Will expire today!";
                        $text .= "$msg - Will expire soon!\n"
                } elsif (day() < 7) {
			$bg = "#F9E79F";
                        push @td, "Will expire in a week!";
                        $text .= "$msg - Will expire in a week!\n"
                } else {
                        push @td, "OK!";
                        $text .= "$msg - OK\n"
                }
        } else {
		$bg = "#E6B0AA";
		push @td, "Expired!";
                $text .= "$msg - Expired!\n"
        }
	push @td, $note;
	$html .= sprintf qq(<tr bgcolor="$bg"><td nowrap=1>%s</td></tr>\n), join('</td><td nowrap=1>',@td);
}
close $fh;
$html .= "</table>\n</td></tr>\n</table>";

exit mailer("Error: ".system("cat $cfile")) unless $text;

eval { mailer($html) };

if ($@) {
	print "[$NOW]\t$@\n";
} else {
	print "[$NOW]\tmail sent\n$text\n";
}

sub mailer { 
	my $c = shift;
	my $csv = 'https://github.com/NSWDAC/Platform/blob/master/Operations/License%20Alert/license-data.csv';
	$c .= "<ul><li>CSV File in GitHub: <a href='$csv'>$csv</a></li>";
	$c .= "<li>Please save the CSV file with CSV format if edited by Microsoft Excel.</li></ul>";
	open MAIL, '|/usr/sbin/sendmail -t' || die "Can't sendmail - $!"; 
	print MAIL "To: $to\n"; 
	print MAIL "From: $from\n"; 
	print MAIL "Subject: $subject\n"; 
	print MAIL qq(Content-Type: text/html; charset=UTF-8\n\n);
	print MAIL $c; 
	close MAIL; 
}

# s or no s for plural num
sub snos {
	my $n = shift;
	return 's' if $n > 1;
}
sub now {
        time + int($offset%86400)*3600
}
sub day {
        my $dd = sprintf "%d", int($diff/86400);
	$dd." day".snos($dd)
}
sub hh {
        my $hh = strftime('%H', localtime($diff));
	$hh." hour".snos($hh)
}
sub mm {
        my $mm = strftime('%M', localtime($diff));
	$mm." minute".snos($mm)
}
sub ss {
        my $ss = strftime('%S', localtime($diff));
	$ss." second".snos($ss)
}
