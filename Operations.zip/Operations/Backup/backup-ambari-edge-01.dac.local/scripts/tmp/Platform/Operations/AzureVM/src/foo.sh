#!/bin/sh

echo "hello world!" >> /tmp/foo-jenkines.log
