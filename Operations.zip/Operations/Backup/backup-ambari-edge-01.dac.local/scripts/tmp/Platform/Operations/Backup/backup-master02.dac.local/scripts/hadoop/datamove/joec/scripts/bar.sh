#! /bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HiveExport
HiveExportpath=/hadoop/datamove/databases/
REMOTEPATH=/analytics/hivebackup
BACKUPDIR=backup_$(date +"%d_%m_%Y")
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

# Script to capture the rebuild Hive command for all tables in all databases

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

log_info "Info: Hive Export Process has started execution at"

databases=`hive -e "show databases;"`

for db in $databases;
	echo $db;
done
