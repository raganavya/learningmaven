#!/usr/bin/perl

my $to = 'Joe.Chiu@treasury.nsw.gov.au';
# my $from = 'Joe.Chiu@treasury.nsw.gov.au';
my $from = "license@$HOSTNAME";
my $subject = "Just a test sample";

eval { mailer() };

if ($@) {
	print "$@\n";
} else {
	print "mail sent\n";
}

sub mailer { 
  open(MAIL, '|/usr/sbin/sendmail -t') or die ("Can't sendmail - $!"); 
  print MAIL "To: $to\n"; 
  print MAIL "From: $from\n"; 
  print MAIL "Subject: $subject\n\n"; 
  print MAIL "Hello world!"; 
  close(MAIL); 
}
