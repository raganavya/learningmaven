#!/bin/bash
###############################################################################
# This is a  script copy files older than a week 
# from /dataproducts/full to /analytics/dataproducts_cold_backup/full and
# from /dataproducts/incr to /analytics/dataproducts_cold_backup/incr
# Cronjob for this Script will run on Friday 18:00 UTC
###############################################################################
# version 1.0
# Developer Chetna S
###############################################################################

#variables for full 
Source_Parent_Dir_full="/dataproducts/test_full"
Weekly_Source_Dir_full="$(date -d "$(date) - 6 day" +"%Y/%m/%d")"
Weekly_S_Dir_full="${Source_Parent_Dir_full}/${Weekly_Source_Dir_full}"
Dis_backup_full="/analytics/dataproducts_cold_backup/test_full"
Yearly_Monthly_DIR_full="${Dis_backup_full}/$(date "+%Y")/$(date "+%m")"

#variables for incr
Source_Parent_Dir="/dataproducts/incr/"
Dis_backup_incr="/analytics/dataproducts_cold_backup/incr"
Yearly_Monthly_DIR="${Dis_backup_incr}/$(date "+%Y")/$(date "+%m")"

#log variable 
LOG_PATH="/dataproducts/log/backup_COPY_$(date +%a%Y%m%d).log"

RSYNC="rsync -avp"

# Log function
function log_info()
 {
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
 }

#start logging 
log_info "Info: Starting incremental backup "

 # create local directory if it doesnt exit
[ ! -d ${Yearly_Monthly_DIR} ] && mkdir -p ${Yearly_Monthly_DIR}

if [ $? -eq 0 ]; then
   log_info "Info: Created directory ${Yearly_Monthly_DIR}"
else
   log_info "Info: Local directory ${Yearly_Monthly_DIR} exists"
fi

# Copy last 7 days file (incremental backup)
ok=0
for i in {0..5}; do
    Source_Dir=$(date -d "$(date) - $i day" +"%Y/%m/%d")
    echo $RSYNC "${Source_Parent_Dir}${Source_Dir}"  "${Yearly_Monthly_DIR}";
    $RSYNC "${Source_Parent_Dir}${Source_Dir}"  "${Yearly_Monthly_DIR}";
    if [ $? -eq 0 ]; then
        log_info "Info: Copy Completed for ${Source_Dir}"
        #rm -rf "${Source_Parent_Dir}${Source_Dir}";
          #if [ $? -eq 0 ]; then
             #log_info "Info: Deletion Complete for ${Source_Dir}"
         #else 
             #log_info "Info: Error in Deleting ${Source_Dir}"
         #fi 
    else 
        log_info "Info:Error($?) in copy of ${Source_Parent_Dir}${Source_Dir}"
        ok=1
    fi
done

if [ $ok -eq 0 ]; then
    log_info "Info: Backup Completed $(date +%Y-%m-%d)"
else 
    log_info "Info:Error in Backup"
fi  

#start logging
log_info "Info: Starting full backup"

 # create local directory if it doesnt exit
[ ! -d ${Yearly_Monthly_DIR_full} ] && mkdir -p ${Yearly_Monthly_DIR_full}

if [ $? -eq 0 ]; then
   log_info "Info: Created directory ${Yearly_Monthly_DIR}"
else
   log_info "Info: Local directory ${Yearly_Monthly_DIR} exists"
fi

# Copy previous Saturday's file

$RSYNC "${Weekly_S_Dir_full}"  "${Yearly_Monthly_DIR_full}";
    if [ $? -eq 0 ]; then
        log_info "Info: Copy Completed for ${Weekly_S_Dir_full}"
        #rm -rf "${Weekly_S_Dir_full}";
          #if [ $? -eq 0 ]; then
             #log_info "Info: Deletion Complete for ${Weekly_S_Dir_full}"
         #else
             #log_info "Info: Error in Deleting ${Weekly_S_Dir_full}"
         #fi
    else
        log_info "Info:Error($?) in Backup ${Weekly_S_Dir_full}"

    fi
