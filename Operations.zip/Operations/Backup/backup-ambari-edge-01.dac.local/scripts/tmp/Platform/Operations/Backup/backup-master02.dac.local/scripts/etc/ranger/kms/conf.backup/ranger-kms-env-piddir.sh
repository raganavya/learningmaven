export RANGER_KMS_PID_DIR_PATH=/var/run/ranger_kms
export KMS_USER=kms