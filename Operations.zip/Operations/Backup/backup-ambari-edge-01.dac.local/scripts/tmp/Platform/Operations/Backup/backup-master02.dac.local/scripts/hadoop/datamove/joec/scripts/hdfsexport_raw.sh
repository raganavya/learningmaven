#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HDFSExport
#HDFSPATH=$1
EXPORTDIR=/hadoop/datamove/data/
REMOTEPATH=/analytics/hdfsbackup
BACKUPDIR=backup_$(date +"%d_%m_%Y")

#Log Path
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS Export Process has started execution at"

log_info "Info: HDFS Export of ${HDFSPATH} directory has started execution at"

hdfs dfs -get /raw/ABS ${EXPORTDIR}
hdfs dfs -get /raw/AustralianBusinessRegister ${EXPORTDIR}
hdfs dfs -get /raw/AustralianSecuritiesInvestmentsCommission ${EXPORTDIR}
hdfs dfs -get /raw/BirthsDeathsMarriages ${EXPORTDIR}
hdfs dfs -get /raw/BureauOfCrimeStatisticsResearch ${EXPORTDIR}
hdfs dfs -get /raw/BureauOfMeteorology ${EXPORTDIR}
hdfs dfs -get /raw/BurningGlassTechnologies ${EXPORTDIR}
hdfs dfs -get /raw/CityOfSydneyCouncil ${EXPORTDIR}
hdfs dfs -get /raw/DepartmentOfIndustry ${EXPORTDIR}
hdfs dfs -get /raw/DeptOfEducation ${EXPORTDIR}
hdfs dfs -get /raw/DeptOfJustice ${EXPORTDIR}
hdfs dfs -get /raw/FACS ${EXPORTDIR}
hdfs dfs -get /raw/FairTrading ${EXPORTDIR}
hdfs dfs -get /raw/MinistryOfHealth ${EXPORTDIR}
hdfs dfs -get /raw/NSWElectoralCommission ${EXPORTDIR}
hdfs dfs -get /raw/NSWProcurement ${EXPORTDIR}
hdfs dfs -get /raw/OneGov ${EXPORTDIR}
hdfs dfs -get /raw/PSMA ${EXPORTDIR}
hdfs dfs -get /raw/SIRA ${EXPORTDIR}
hdfs dfs -get /raw/ServiceNSW ${EXPORTDIR}
hdfs dfs -get /raw/TfNSW ${EXPORTDIR}
#hdfs dfs -get /raw/Archive ${EXPORTDIR}

if [ $? -ne 0 ]; then
	log_info "Error: HDFS Export of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Export of ${HDFSPATH} directory has completed execution at"

rsync -r ${EXPORTDIR}/${HDFSPATH} backup-master01:${REMOTEPATH}/${BACKUPDIR}/

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${EXPORTDIR}${HDFSPATH} Directory has failed execution at"
        exit
fi

rm -rf ${EXPORTDIR}/${HDFSPATH}

log_info "Info: SCP Process for ${EXPORTDIR}${HDFSPATH} directory has completed execution at"

log_info "Info: HDFS Export Process has completed execution at"
