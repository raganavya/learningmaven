#!/bin/bash

###############################################################
# Copy dataproducts backup files from dp-mysql-data-02
# to backup-master01.
# This is a data pull
###############################################################
# Version: 1.0
# Developer: Indu N
###############################################################

export LC_ALL=C

#Variables
PARENT_DIR="/db/mysql_backup"
REMOTE_DIR="${PARENT_DIR}/$(date +%a%Y%m%d)"
LOG_FILE="${REMOTE_DIR}/backup-progress.log"
REMOTE_HOST="dp-mysql-data-02"
LOCAL_DIR="/dataproducts"
LOG_PATH="/dataproducts/log/COPY_$(date +%a%Y%m%d).log"
BACKUP_LOG="/dataproducts/log/backuptail$(date +%a%Y%m%d).log"

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}


#ssh -i /root/dace2_data_product_root_private_key root@dp-mysql-data-02 "tail -1 /db/mysql_backup/Thu20171221/backup-progress.log" 2>${LOG_PATH} 
ssh -i /root/dace2_data_product_root_private_key root@dp-mysql-data-02 "tail /db/mysql_backup/Thu20171221/backup-progress.log" > "${BACKUP_LOG}"

