IMG=dp-mysql-data-02.img
ZIMG=/db/backup/$IMG
TIMG=/analytics/sira_mysql_backup/azure/$IMG
LOG=/tmp/dm-migration.log

FROM=10.74.13.104
TO=10.71.50.8

echo "scp from $FROM" >> $LOG
scp 10.74.13.104:$ZIMG $TIMG >> $LOG 2>&1
echo "scp to $TO" >> $LOG
scp $TIMG $TO:$ZIMG >> $LOG 2>&1
echo "$IMG transferred" >> $LOG
ssh $TO 'cd /root/joec/migration; sh restore-data.sh' >> $LOG 2>&1
echo "MySQL database from $FROM to $TO migration finished" >> $LOG

rm -f $TIMG >> $LOG 2>&1
echo "$TIMG removed" >> $LOG
echo
echo
echo
echo
echo
