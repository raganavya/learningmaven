#! /bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HiveExport
HiveExportpath=/hadoop/datamove/databases/
REMOTEPATH=/analytics/hivebackup
BACKUPDIR=backup_$(date +"%d_%m_%Y")
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

# Script to capture the rebuild Hive command for all tables in all databases

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

log_info "Info: Hive Export Process has started execution at"

databases=`hive -e "show databases;"`

for db in $databases;
	do
		log_info "Info: Hive extract of ${db} has started execution at"
		mkdir -p ${HiveExportpath}${db}
		tables=`hive -e "use ${db}; show tables;"`
		
		for t in $tables;
			do
                                log_info "Info: Hive extract of ${db}/${t} has started execution at"
				hive -e "use ${db}; show create table ${t};" > ${HiveExportpath}${db}/${t}
				log_info "Info: Hive extract of ${db}/${t} has completed execution at"
			done
log_info "Info: Hive extract of ${db} has completed execution at"
	done

if [ $? -ne 0 ]; then
        log_info "Error: Hive extract has failed execution at"
        exit
fi

#rsync -r ${HiveExportpath} root@backup-master01:${REMOTEPATH}/${BACKUPDIR}

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${HiveExportpath} directory has failed execution at"
        exit
fi

#rm -rf ${HiveExportpath}/*

log_info "Info: SCP Process for ${HiveExportpath} directory has completed execution at"

log_info "Info: Hive Export Process has completed execution at"

