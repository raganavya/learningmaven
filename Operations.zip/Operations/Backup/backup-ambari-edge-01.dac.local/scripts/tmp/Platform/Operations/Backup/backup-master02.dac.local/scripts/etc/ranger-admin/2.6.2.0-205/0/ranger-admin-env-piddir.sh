export RANGER_PID_DIR_PATH=/var/run/ranger
export RANGER_USER=ranger