#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

for folderName in apps; do
  ./hdfsexport.sh $folderName
done 
