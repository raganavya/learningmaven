#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HDFSExport
HDFSPATH=$1
EXPORTDIR=/hadoop/datamove/data/
REMOTEPATH=/analytics/hdfsbackup
# BACKUPDIR=backup_$(date +"%d_%m_%Y")
BACKUPDIR=manual_backup_hdfs

#Log Path
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS Export Process has started execution at"

log_info "Info: HDFS Export of ${HDFSPATH} directory has started execution at"

hdfs dfs -get /${HDFSPATH} ${EXPORTDIR}
#hdfs dfs -get /raw/SIRA ${EXPORTDIR}

if [ $? -ne 0 ]; then
	log_info "Error: HDFS Export of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Export of ${HDFSPATH} directory has completed execution at"

rsync --ignore-existing -r ${EXPORTDIR}/${HDFSPATH} backup-master01:${REMOTEPATH}/${BACKUPDIR}/

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${EXPORTDIR}${HDFSPATH} Directory has failed execution at"
        exit
fi

rm -rf ${EXPORTDIR}/${HDFSPATH}

log_info "Info: SCP Process for ${EXPORTDIR}${HDFSPATH} directory has completed execution at"

log_info "Info: HDFS Export Process has completed execution at"
