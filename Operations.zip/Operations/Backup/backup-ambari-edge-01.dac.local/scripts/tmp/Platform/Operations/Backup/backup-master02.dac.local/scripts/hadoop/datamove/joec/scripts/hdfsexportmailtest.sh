#!/bin/bash

###############################################################
# HDFS Backup script for DACE2 Analytics Cluster
# Version: 1.0
###############################################################

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HDFSExport
HDFSPATH="$1"
EXPORTDIR="/hadoop/datamove/data/"
REMOTEPATH="/analytics"
#Log Path
LOGPATH=/hadoop/datamove/log
LOGFILE=${LOGPATH}/${JOB}.log
#Email
EMAIL="manan.tyagi@finance.nsw.gov.au"

function log_info()
{
    log_time=`date "+%Y-%m-%d-%H-%M-%S"`
    echo -e "$* $log_time" >> ${LOGFILE}
}

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS Export Process has started execution at"

log_info "Info: HDFS Export of ${HDFSPATH} directory has started execution at"

hdfs dfs -get /${HDFSPATH} ${EXPORTDIR}

if [ $? -ne 0 ]; then
        log_info "Error: HDFS Export of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Export of ${HDFSPATH} directory has completed execution at"

scp -r -q ${EXPORTDIR}/${HDFSPATH} backup-master01:${REMOTEPATH}/

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${EXPORTDIR}${HDFSPATH} Directory has failed execution at"
        exit
fi

rm -rf ${EXPORTDIR}/${HDFSPATH}

log_info "Info: SCP Process for ${EXPORTDIR}${HDFSPATH} directory has completed execution at"

# Send an email
cd ${LOGPATH}
zip -v $JOB.log.zip $JOB.log

mailSubject="HDFS Backup Mail Notification for Execution Date=$date"
to=$EMAIL
mailContent="$LOGPATH/$JOB.log"
attachment=$JOB.log.zip
(
echo To: $to
echo Subject: $mailSubject
echo "Mime-Version: 1.0"
echo 'Content-Type: multipart/mixed; boundary="GvXjxJ+pjyke8COw"'
echo "" 
echo "--GvXjxJ+pjyke8COw" 
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
echo "" 
cat $mailContent
echo "" 
echo "--GvXjxJ+pjyke8COw"
echo "Content-Type: application/zip"
echo "Content-Transfer-Encoding: base64"
echo "Content-Disposition: attachment; filename=$job.log.zip"
echo "" 
base64 $attachment
) | /usr/sbin/sendmail -t

#rm -v $JOB.log.zip

log_info "Info: HDFS Export Process has completed execution at"

