#!/bin/sh

hdfs dfs -ls -R ../../raw | awk '{print $8}' > /tmp/raw_contents.txt
cat /tmp/raw_contents.txt | grep '[[:space:]]'
