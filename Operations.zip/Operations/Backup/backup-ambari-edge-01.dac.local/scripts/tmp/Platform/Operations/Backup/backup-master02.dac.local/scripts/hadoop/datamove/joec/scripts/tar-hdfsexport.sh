#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

. ./config.inc

HDFSPATH=$1

#Log Path
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS Export Process has started execution at"

log_info "Info: HDFS Export of ${HDFSPATH} directory has started execution at"

echo "/usr/bin/ssh backup-master01 '/usr/bin/mkdir -p ${REMOTEPATH}/${BACKUPDIR}'"
/usr/bin/ssh backup-master01 "mkdir -p ${REMOTEPATH}/${BACKUPDIR}"

if [ ${HDFSPATH} != "raw" ];
then
	echo "hdfs dfs -get /${HDFSPATH} ${EXPORTDIR}"
	hdfs dfs -get /${HDFSPATH} ${EXPORTDIR}
else
	echo "Info: skipping hdfs dfs get the raw's data since it's done beforehand"
	log_info "Info: skipping hdfs dfs get the raw's data since it's done beforehand"
fi

if [ $? -ne 0 ]; then
	log_info "Error: HDFS Export of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Export of ${HDFSPATH} directory has completed execution at"

## rsync -r ${EXPORTDIR}${HDFSPATH} backup-master01:${REMOTEPATH}/${BACKUPDIR}/

echo "/usr/bin/tar zcvf - ${EXPORTDIR}${HDFSPATH} | gzip -c | ssh backup-master01 'cat > ${REMOTEPATH}/${BACKUPDIR}/${HDFSPATH}.tar.gz'"
/usr/bin/tar zcvf - ${EXPORTDIR}${HDFSPATH} | gzip -c | ssh backup-master01 "cat > ${REMOTEPATH}/${BACKUPDIR}/${HDFSPATH}.tar.gz"

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${EXPORTDIR}${HDFSPATH} Directory has failed execution at"
        exit
fi

echo "rm -rf ${EXPORTDIR}${HDFSPATH}"
rm -rf ${EXPORTDIR}${HDFSPATH}

log_info "Info: SCP Process for ${EXPORTDIR}${HDFSPATH} directory has completed execution at"

log_info "Info: HDFS Export Process has completed execution at"


