export USERSYNC_PID_DIR_PATH=/var/run/ranger
export UNIX_USERSYNC_USER=ranger