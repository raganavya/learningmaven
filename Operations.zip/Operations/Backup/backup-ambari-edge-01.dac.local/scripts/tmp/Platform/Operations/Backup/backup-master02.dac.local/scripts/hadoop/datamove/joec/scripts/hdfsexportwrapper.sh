#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

JOB=HDFSExport
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log
emailAddress="manan.tyagi@treasury.nsw.gov.au"
mailContent="$LOG_PATH"
attachment="$LOG_PATH"
RUN_DT=$(date +"%d_%m_%Y")

for folderName in source sandbox apps user projects; do
#for folderName in user; do
  ./hdfsexport.sh $folderName
done 

#mailSubject="HDFS BackUp Status for $RUN_DT"
#to=$emailAddress
#mailContent="$LOG_PATH"
#attachment=$LOG_PATH
#(
#echo To: $to
#echo Subject: $mailSubject
#echo "Mime-Version: 1.0"
#echo 'Content-Type: multipart/mixed; boundary="GvXjxJ+pjyke8COw"'
#echo "" 
#echo "--GvXjxJ+pjyke8COw" 
#echo "Content-Type: text/html"
#echo "Content-Disposition: inline"
#echo "" 
#cat $mailContent
#echo "" 
#echo "--GvXjxJ+pjyke8COw"
#echo "Content-Type: application/zip"
#echo "Content-Transfer-Encoding: base64"
#echo "Content-Disposition: attachment; filename=$job.log.zip"
#echo "" 
#base64 $attachment
#) | /usr/sbin/sendmail -t
