
sub icons;

binmode STDOUT, ":utf8";
print icon(),"\n";

sub icon {
	my @icons = qw/ &#9731 &#9788 &#9786 /;
	srand (time ^ $$ ^ unpack "%L*", `ps axww | gzip -f`);
	# zodiac constellations
	my @z = icons 9800, 12;
	# planets
	my @p = icons 9795, 5;
	# yi
	my @y = icons 9775, 9;
	push @icons, @z, @p, @y;
	return $icons[rand @icons];
}
sub icons {
	my $s = shift;
	my $e = shift;
	return map { '&#'.($s +$_).';' }(0..$e-1);
}
