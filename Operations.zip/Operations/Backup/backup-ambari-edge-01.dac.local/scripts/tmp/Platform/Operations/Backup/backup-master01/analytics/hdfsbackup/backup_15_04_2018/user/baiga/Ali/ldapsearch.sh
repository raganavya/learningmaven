#!/bin/sh
ldapsearch -xv -H ldap://p-dc-101.dac.local:389 -b DC=dac,DC=local -D baiga@dac.local -W (sAMAccountName=*)
