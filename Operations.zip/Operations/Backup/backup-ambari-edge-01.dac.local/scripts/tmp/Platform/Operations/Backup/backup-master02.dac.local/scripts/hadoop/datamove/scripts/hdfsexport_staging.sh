#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HDFSExport
#HDFSPATH=$1
EXPORTDIR=/hadoop/datamove/data/
REMOTEPATH=/hadoop01/datamove
BACKUPDIR=backup_$(date +"%d_%m_%Y")

#Log Path
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS Export of ${HDFSPATH} directory has started execution at"

hdfs dfs -get /staging/2.09.2_SIRA_DASH ${EXPORTDIR}
hdfs dfs -get /staging/2.12_TFM ${EXPORTDIR}
hdfs dfs -get /staging/CoS ${EXPORTDIR}
hdfs dfs -get /staging/SIRAHBC ${EXPORTDIR}
hdfs dfs -get /staging/SIRA_DRS ${EXPORTDIR}
hdfs dfs -get /staging/Telematics ${EXPORTDIR}
hdfs dfs -get /staging/ctp ${EXPORTDIR}
hdfs dfs -get /staging/educationhsc ${EXPORTDIR}
hdfs dfs -get /staging/hsdh ${EXPORTDIR}
hdfs dfs -get /staging/lzpentest ${EXPORTDIR}
hdfs dfs -get /staging/servian ${EXPORTDIR}
hdfs dfs -get /staging/siracrs ${EXPORTDIR}
hdfs dfs -get /staging/siractp ${EXPORTDIR}
hdfs dfs -get /staging/siradrs ${EXPORTDIR}
hdfs dfs -get /staging/sirapolicy ${EXPORTDIR}
hdfs dfs -get /staging/stagingtest ${EXPORTDIR}

if [ $? -ne 0 ]; then
	log_info "Error: HDFS Export of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Export of ${HDFSPATH} directory has completed execution at"

rsync -r ${EXPORTDIR}/${HDFSPATH} backup-master01:${REMOTEPATH}/${BACKUPDIR}/

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${EXPORTDIR}${HDFSPATH} Directory has failed execution at"
        exit
fi

rm -rf ${EXPORTDIR}/${HDFSPATH}

log_info "Info: SCP Process for ${EXPORTDIR}${HDFSPATH} directory has completed execution at"

log_info "Info: HDFS Export Process has completed execution at"
