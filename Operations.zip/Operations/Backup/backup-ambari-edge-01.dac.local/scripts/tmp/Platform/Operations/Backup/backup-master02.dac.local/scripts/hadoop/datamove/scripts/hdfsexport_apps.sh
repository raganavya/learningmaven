#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HDFSExport
#HDFSPATH=$1
EXPORTDIR=/hadoop/datamove/data/
REMOTEPATH=/hadoop01/datamove
BACKUPDIR=backup_$(date +"%d_%m_%Y")

#Log Path
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS Export of ${HDFSPATH} directory has started execution at"

hdfs dfs -get /projects/2_02_Heatwaves ${EXPORTDIR}
hdfs dfs -get /projects/2_09_SIRA_Dash ${EXPORTDIR}
hdfs dfs -get /projects/2_12_Their_Futures_Matter ${EXPORTDIR}
hdfs dfs -get /projects/3_01_Defibrillator_Networks ${EXPORTDIR}
hdfs dfs -get /projects/4_02_Freight_Analytics ${EXPORTDIR}
hdfs dfs -get /projects/4_06_Housing_Fraud ${EXPORTDIR}
hdfs dfs -get /projects/4_08_Ambulance_Audit ${EXPORTDIR}
hdfs dfs -get /projects/DAC617_SIRA_Data_Investigation ${EXPORTDIR}
hdfs dfs -get /projects/DAC618_Night_Time_Economy ${EXPORTDIR}
hdfs dfs -get /projects/DAC620_Automation ${EXPORTDIR}
hdfs dfs -get /projects/DAC628_SIRA_Telematics ${EXPORTDIR}
hdfs dfs -get /projects/DAC630_PIU_Rental_Vacancies ${EXPORTDIR}
hdfs dfs -get /projects/DAC636_Their_Futures_Matter_CWU ${EXPORTDIR}
hdfs dfs -get /projects/DAC_Active_Kids ${EXPORTDIR}
hdfs dfs -get /projects/Geodemographics ${EXPORTDIR}
hdfs dfs -get /projects/SIRA_CRS ${EXPORTDIR}
hdfs dfs -get /projects/SIRA_CTP ${EXPORTDIR}
hdfs dfs -get /projects/_SIRA_CTP_NLP ${EXPORTDIR}

if [ $? -ne 0 ]; then
	log_info "Error: HDFS Export of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Export of ${HDFSPATH} directory has completed execution at"

rsync -r ${EXPORTDIR}/${HDFSPATH} backup-master01:${REMOTEPATH}/${BACKUPDIR}/

if [ $? -ne 0 ]; then
        log_info "Error: SCP of ${EXPORTDIR}${HDFSPATH} Directory has failed execution at"
        exit
fi

rm -rf ${EXPORTDIR}/${HDFSPATH}

log_info "Info: SCP Process for ${EXPORTDIR}${HDFSPATH} directory has completed execution at"

log_info "Info: HDFS Export Process has completed execution at"
