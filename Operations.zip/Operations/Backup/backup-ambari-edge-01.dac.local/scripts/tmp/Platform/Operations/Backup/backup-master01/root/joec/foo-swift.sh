#!/bin/sh

export OS_PROJECT_ID=bea24bf2b3fc4d5cb9e2a894eb594e8e
export OS_PROJECT_NAME="DAC"
export OS_USER_DOMAIN_NAME="Default"
export OS_REGION_NAME="RegionOne"
export OS_INTERFACE=public
export OS_IDENTITY_API_VERSION=3
export OS_PASSWORD=tX6rvhkwTU%=y%g5
swift list DAC_BACKUP

