#!/bin/bash

REMOTE_HOST="dp-mysql-data-02"
PARENT_INCR_DIR="/db/mysql_backup/incr"
PARENT_FULL_DIR="/db/mysql_backup/full"
REMOTE_INCR_DIR="${PARENT_INCR_DIR}/$(date "+%Y")/$(date "+%m")/$(date "+%d")"
LOCAL_PARENT_INCR_DIR="/dataproducts/incr"
LOCAL_PARENT_FULL_DIR="/dataproducts/full"
TODAYS_INCR_DIR="${LOCAL_PARENT_INCR_DIR}/$(date "+%Y")/$(date "+%m")"
TODAYS_FULL_DIR="${LOCAL_PARENT_FULL_DIR}/$(date "+%Y")"
date_path=$(date "+%Y/%m/%d")

todays_dir=${REMOTE_INCR_DIR}/${date_path}

#[ ! -d $backup_path ] &&
 echo "REMOTE_INCR_DIR:"$REMOTE_INCR_DIR
 echo "TODAYS_INCR_DIR:"$TODAYS_INCR_DIR

[ ! -d $TODAYS_INCR_DIR ] && mkdir -p $TODAYS_INCR_DIR

#ssh -i /root/dace2_data_product_root_private_key root@dp-mysql-data-02  "test -e /db/mysql_backup/incr/2018/01/28"
ssh -i /root/dace2_data_product_root_private_key root@dp-mysql-data-02  "test -e ${REMOTE_INCR_DIR}"

if [ $? -eq 0 ]; then
   echo "File ${REMOTE_INCR_DIR}@${REMOTE_HOST} exists"
   # ssh -i /root/dace2_data_product_root_private_key root@dp-mysql-data-02  "rsync -re ${REMOTE_DIR} $TODAYS_DIR"
#   rsync -re  "ssh -i /root/dace2_data_product_root_private_key" root@${REMOTE_HOST}:${REMOTE_FULL_DIR} ${TODAYS_FULL_DIR}
   rsync -re  "ssh -i /root/dace2_data_product_root_private_key" root@${REMOTE_HOST}:${REMOTE_INCR_DIR} ${TODAYS_INCR_DIR}
   
else
   echo "File ${REMOTE_INCR_DIR}@${REMOTE_HOST} doesnot exist"
fi

