#!/bin/bash

######################################################################################################################
# Setting Input & Processing parameters for the process execution                                                    #
######################################################################################################################

#Job Name
JOB=HDFSZIP
HDFSPATH=/raw/Archive/Sensitive/*
EXPORTDIR=/hadoop/datamove/data/

#Log Path
LOG_PATH=/hadoop/datamove/log/${JOB}_$(date +"%d_%m_%Y").log

function log_info()
{
    log_time=`date "+%Y-%m-%d:%H:%M:%S"`
    echo -e "$* $log_time" >> ${LOG_PATH}
}

#kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

log_info "Info: HDFS ZIP Process has started execution at"


hdfs dfs -get ${HDFSPATH} ${EXPORTDIR}

if [ $? -ne 0 ]; then
	log_info "Error: HDFS Copy to Local of ${HDFSPATH} directory has failed execution at"
        exit
fi

log_info "Info: HDFS Copy to Local of ${HDFSPATH} directory has completed execution at"

cd ${EXPORTDIR}

for dir in `ls`; do tar -cvzf ${dir}.tar.gz ${dir}; done

log_info "Info: Compression for directories has completed execution at"

#hdfs dfs -put ${EXPORTDIR} ${HDFSPATH}


if [ $? -ne 0 ]; then
        log_info "Error: HDFS put to ${HDFSPATH} directory has failed execution at"
        exit
fi


log_info "Info: Upload to HDFS has completed execution at"

log_info "Info: HDFS Zip Process has completed execution at"
