cd /tmp/
[ -d Platform ] || git clone https://github.com/NSWDAC/Platform.git
[ -d Platform/Operations/Backup/backup-$HOSTNAME ] || mkdir -p Platform/Operations/Backup/backup-$HOSTNAME
DIR=/tmp/script-backup
[ -d $DIR ] && rm -rf $DIR
mkdir $DIR
[ -d $DIR/scripts ] || mkdir $DIR/scripts
for user in $(cut -f1 -d: /etc/passwd); do echo $user; crontab -u $user -l >> $DIR/cron-all-user-list 2>&1 ; done
for i in `find / -name '*.sh'`; do cp --parents $i $DIR/scripts/.; done 2>/dev/null
for i in `find / -name '*.pl' | grep -v 'perl5' | grep -v 'share'`; do cp --parents $i $DIR/scripts/.; done

cp -rf $DIR/* Platform/Operations/Backup/backup-$HOSTNAME/.

