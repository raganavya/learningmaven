#!/bin/bash
#rm -f tableNames.txt
rm -f HiveTableDDL.txt
#hive -e "use ctp; show tables;" > tableNames.txt  
#wait
cat tableNames.txt |while read LINE
   do
   hive -e "use ctp;show create table $LINE" >>HiveTableDDL.txt
   echo  -e "\n" >> HiveTableDDL.txt
   done
#rm -f tableNames.txt
echo "Table DDL generated"