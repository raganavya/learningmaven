use MIME::Lite;
use Text::Template;
use constant TEST => 1;

sub CC;
sub BCC;

$user = shift || die "no customer name input";
$h = {
  customer => $user,
  fullname => 'Parvinder Singh',
  position => 'Assistant DevOps Engineer, DCS DAC Service Management',
  mobileno => '0424260705',
  mailaddr => 'parvinder.singh@customerservice.nsw.gov.au',
};

my $template = Text::Template->new(SOURCE => '/home/parvinder.singh/email-temp.tml')
  or die "Couldn't construct template: $Text::Template::ERROR";

$content = $template->fill_in(HASH => $h) ||
  die "Couldn't fill in template: $Text::Template::ERROR";

$tt = {
  jc => 'joe.chiu@customerservice.nsw.gov.au',
  mt => 'Manan.Tyagi@customerservice.nsw.gov.au',
  ps => 'parvinder.singh@customerservice.nsw.gov.au',
  ds => 'damien.smith@customerservice.nsw.gov.au',
  in => 'Indu.Neelakandan@customerservice.nsw.gov.au',
  sh => 'Simon.Herbert@customerservice.nsw.gov.au',
  az => 'Angela.Zinn1@customerservice.nsw.gov.au',
};

my $from = $tt->{'ps'};

@file = (
  "/home/parvinder.singh/okta/DAC\ COVID19\ Dashboard\ Portal\ Access\ Report.csv",
);
$to = $tt->{'ps'};

$cc = CC;
$bcc = BCC;

if (TEST) {
  print "TEST Mode (disabled CC and BCC):\nBCC: $bcc\n";
  $bcc = '';
}

my $msg = MIME::Lite->new(
  From    => $from,
  To      => $to,
  Cc      => $cc,
  Bcc      => $bcc,
  Subject => 'Last 7 days Okta report',
  Type    => 'text/html',
  Data    => "$content\n", 
);
$msg->attach(
  Type => 'image/jpg',
  Id   => 'logo.jpg',
  Path => '/home/azureuser/logo.jpg',
);
foreach $file (@file) {
  print "attaching $file...\n";
  $msg->attach(
    Path    => $file,
    Type    =>'application/csv'
  );
}
$msg->send;
print "sent to $to\n";

# address array to string with comma
sub a2s {
  return join ',', map { $tt->{$_} } @_;
}

sub CC {
  return a2s qw/ jc ds /;
}

sub BCC {
  return a2s qw / in ds ps jc /;
}

__DATA__

