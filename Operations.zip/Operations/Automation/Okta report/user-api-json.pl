use Data::Dumper;
use JSON;

sub noq;

$s = <>;
$csvfile = "/home/parvinder.singh/okta/poc/oktauserlist.csv";

@head = (
  "firstName",
  "lastName",
  "email",
  "status",
  "activation date",
  "lastLogin",
  "lastpasswordchange"
);
$js = from_json($s);
open FILE, "> $csvfile" || die "$! - $csvfile";
print q(").join('","',@head).q("),"\n";
foreach $ss (@$js) {
  $j = from_json($ss);
  @c = ();
  foreach $h (@$j) {
#    foreach $t (@{$h->{target}}){
#      if ($t->{type} =~ /AppInstance/i) {
#        $c5 = noq $t->{alternateId}
#      } else {
#        next;
#      }
#    }
#    $c2 = noq $h->{actor}->{displayName};
#    $c4 = noq join ", ", map { $_->{displayName} } @{$h->{target}};
#    $c3 = noq $h->{displayMessage};
#    $c5 || next;
#    $c6 = noq $h->{outcome}->{result};
    $c1 = noq $h->{profile}->{firstName};
    $c2 = noq $h->{profile}->{lastName};
    $c3 = noq $h->{profile}->{email};
    $c4 = noq $h->{status};
    $c5 = noq $h->{activated};
    $c6 = noq $h->{lastLogin};
    $c7 = noq $h->{passwordChanged};
    push @c, qq("$c1","$c2","$c3","$c4","$c5","$c6","$c7");
  }

  foreach $c (@c) {
    print FILE "$c\n";
  }
}
close FILE;

sub noq {
  $ss = shift;  
  $ss =~ s/\"/\\"/;
  return $ss;
}
