import requests

import json

from pathlib import Path

import csv

 
# Define Okta API base URL

base_okta_url = "https://YOUR-OKTA-NAME.okta.com"

 
# Define the API token required by Okta

okta_apikey = "PUT-YOUR-OKTA-API-TOKEN-HERE"

 
# Define record limit (200 is the maximum accepted by Okta)

limit = 200

 
# If get_all_data is True, then the script will call Get User until all data is retrieved.

get_all_data = True

#get_all_data = False

 
# Define the Okta Users endpoint

url = base_okta_url + "/api/v1/users" + "?limit=" + str(limit)

 
# CSV - JSON Response Mapping

# ADD OTHER OKTA ATTRIBUTES OR CHANGE THE ORDER OF COLUMNS FOR THE CSV BELOW

column_list = ["firstName","lastName","displayName","manager","title","login","email","department"]

 
# Construct the headers

headers = {

  'content-type': 'application/json',

'Authorization': 'SSWS ' + okta_apikey

}

 
# Setup path for current directory and file name for the Export file

data_folder = Path(".")

export_file = data_folder / "okta_user_export.csv"

exportfile = open(export_file,"w+")

# Join the values from the column list to build a CSV title row, with delimeters

col_headings = '"' + '", "'.join(column_list) + '"'

exportfile.write(col_headings)

csv_delim = '","'

 
# Set conditions for while loop. Used with pagination.

next = False

first = True

next_url = ""

 
# While loop use to control first and subsequent requests

while (next or first):

# If next_url is defined, this is not the first time through the loop,

# and we should have the next_url generated from Okta

response_json = []


# If this is the second (or greater) call to Get Users

if next:

# Make the API call

response = requests.request("GET", next_url, headers=headers)

response_json = response.json()

# Parse the LINK headers from the response.

response_links = requests.utils.parse_header_links(response.headers['Link'].rstrip('>').replace('>,<', ',<'))

next_url = ""

# Look for the 'next' url in the response links.

for linkobj in response_links:

if linkobj['rel'] == 'next':

next_url = linkobj['url']

next = True

else:

next = False

# If this is the first call to Get Users

if first:

# Make the request to Okta and record the response

response = requests.request("GET", url, headers=headers)

response_json = response.json()

# Parse the LINK headers from the response.

if (response.status_code == 200):

response_links = requests.utils.parse_header_links(response.headers['Link'].rstrip('>').replace('>,<', ',<'))

next_url = ""

for linkobj in response_links:

#print(linkobj['rel'])

if linkobj['rel'] == 'next':

next_url = linkobj['url']

next = True

 
# Turn off first flag so that the next option is selected on subsequent loops

first = False

else:

print(response.status_code)

print(response_json)

exit(1)


# write the response to file

for entry in response_json:

# Build the CSV row

csv_record = []

# Loop through in column in the column list

for col in column_list:

# If we can find column in profile object append it

if col in entry['profile']:

csv_record.append(entry['profile'][col])

# Else if we can find column in root object append it

elif col in entry:

csv_record.append(entry[col])

# Else if we can't find, write a dash to preserve column format

else:

csv_record.append("-")


# Write the CSV row to the file

csv_line = '"' + csv_delim.join( csv_record ) + '"'

exportfile.write("%s\n" % (csv_line))


# If we don't want to get all data (i,e we only want 'limit' records), exit the loop.

if get_all_data == False:

break


exportfile.close

print("Done.")
