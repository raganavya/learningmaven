#!/usr/bin/env python

import requests
import json
import time
from datetime import datetime, timedelta

  
api_url = "https://dacnsw.okta.com/api/v1/logs"
days = datetime.utcnow() - timedelta(days=7)
since = str(days.strftime('%Y-%m-%dT%H:%M:%S.000Z'))
url = api_url.format()
params = {
        'since': since
    }
arr = []

headers = {
    'Accept': "application/json",
    'Content-Type': "application/json",
    'Authorization': "SSWS 00JAIyMTncuOzXMO2gMpTNTQ1v_ihGWULv6_sGEo2g"
    }
payload = ""

def req(url):
  return requests.request("GET", url, params=params, data=payload, headers=headers)

def nexturl(r):
  if not r: return False
  return r.links['next']['url']

r = req(url)
arr.append(r.text)

while 'next' in r.links and r.links['next']['url'] != r.links['self']['url']:
  url = nexturl(r)
  r = req(url)
  arr.append(r.text)
  
print json.dumps(arr)
