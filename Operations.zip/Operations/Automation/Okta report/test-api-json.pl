use Data::Dumper;
use JSON;

sub noq;

$s = <>;

@head = (
  "Timestamp",
  "Actor (who performed action on)",
  "Display Message",
  "Target(details)",
  "Target (dashboard)",
  "Result"
);
$js = from_json($s);

print q(").join('","',@head).q("),"\n";
foreach $ss (@$js) {
  $j = from_json($ss);
  @c = ();
  foreach $h (@$j) {
    foreach $t (@{$h->{target}}){
      if ($t->{type} =~ /AppInstance/i) {
        $c5 = noq $t->{alternateId}
      } else {
        next;
      }
    }
    $c2 = noq $h->{actor}->{displayName};
    $c4 = noq join ", ", map { $_->{displayName} } @{$h->{target}};
    $c3 = noq $h->{displayMessage};
    $c5 || next;
    $c6 = noq $h->{outcome}->{result};
    $c1 = noq $h->{published};
    push @c, qq("$c1","$c2","$c3","$c4","$c5","$c6");
  }

  foreach $c (@c) {
    print "$c\n";
  }
}

sub noq {
  $ss = shift;  
  $ss =~ s/\"/\\"/;
  return $ss;
}

__END__
(1) published     (2) displayName (3) displayMessage  (4) result 
actor displayName
target displayName
displayMessage
alternateId 
result
published

