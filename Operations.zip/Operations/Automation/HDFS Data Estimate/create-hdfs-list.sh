#!/bin/sh

kinit hdfs-dace2@DAC.LOCAL -kt /etc/security/keytabs/hdfs.headless.keytab

FILE=files-hdfs.list
hdfs dfs -ls -R / | grep -v '.Trash' | awk '{print $1 " " $8}' > $FILE

