#!/usr/bin/perl

use strict;
use Data::Dumper;
use POSIX 'strftime';
use MIME::Lite;
use constant MAIL => 1;

sub mail;

my $NOW = strftime '%Y-%m-%d %H:%M:%S', localtime;
my $TODAY = strftime '%Y-%m-%d', localtime;

my $dir = 'apps';

my %sh;
my $dh;
my $fh;
my $m = {
  joe => 'Joe.Chiu@customerservice.nsw.gov.au',
  ps => 'parvinder.singh@customerservice.nsw.gov.au',
};
my $html = qq(<p><b style='font-size:20px'>DAILY ALERT DETAILS</b></p>
<table border=0 cellspacing=0 cellpadding=6 width=68% style='border-right: 1px solid black;'>
);
my $f = './hdfs-data-estimate.csv';
my @dir = qw{
    app-logs
    apps
    ats
    benchmarks
    hdp
    livy2-recovery
    mapred
    mr-history
    projects
    ranger
    rangerbackup
    raw
    sandbox
    solr
    source
    spark2-history
    staging
    tmp
    user
    zone-encr
};
my @head = ("Directory Paths","Directory Size (GB)","Directory Count","File Count");
my $head = '"'.join('","', @head).'"';
my $hf = shift || 'files-hdfs.list';
my $cmd_size = q(hdfs dfs -du / | perl -ne '@a=split /\s{2,}/; $a[1]=~s/ //; chomp $a[2];print $a[2],"\n",$a[1],"\n"');
my @sh = `$cmd_size`; chomp @sh;
my %sh = @sh;

open FILE, $hf;
while (<FILE>) {
    chomp;
    my ($p, $fd) = split ' ';
    if (/^d/) {
        d($fd);
    } else {
        f($fd);
    }
}
close FILE;

my $r => q(border-right: 1px solid black;);
my $l => q(border-left: 1px solid black;);
my $b => q(border-bottom: 1px solid black;);

open FILE, "> $f";
print FILE $head,"\n";
$html .= q(<tr bgcolor=black><td><b>).join('</b></td>',@head).q(</tr>);
foreach my $d (@dir) {
    $d eq '/' && next;
    my $rec = sprintf "%s,%0.2f,%d,%d\n", $d, B($sh{'/'.$d},3), $dh->{$d}, $fh->{$d};
    print FILE $rec;
    $html .= sprintf "<tr><td style='$r$l$b'>%s</td><td style='$r$b'>%0.2f</td><td style='$r$b'>%d</td><td style='$r$b'>%d</td>\n", $d, B($sh{'/'.$d},3), $dh->{$d}, $fh->{$d};
}
close FILE;

mail if MAIL;

sub d {
    my $fd = shift;
    my $d = (split '/', $fd)[1];
    if (grep { $_ eq $d } @dir) {
        $dh->{$d}++;
    }
}

sub f {
    my $fd = shift;
    my $d = (split '/', $fd)[1];
    if (grep { $_ eq $d } @dir) {
        $fh->{$d}++;
    }
}

sub B {
    my $b = shift;
    my $n = shift;
    my @u = qw/null bytes KB GB TB/;
    $b = $b/1024.0 foreach (1..$n);
    return $b
}

sub mail {
  my @to = ($m->{joe},$m->{ps});
  my $to = join ',', @to;
  my $from = $m->{joe};
  my $subject = "Weekly HDFS Data Estimate Report - $NOW";
  $html .= '</table>';

  $html = "<p>Test mail sending with an attachment - <b>$f</b></p>\n<br>Blah blah\n";

  my $msg = MIME::Lite->new(
    From    => $from,
    To      => $to,
    Subject => $subject,
    Data    => $html,
    Type    =>'text/html',
  );
  $msg->attach(
    Path    => $f,
  );
  $msg->send;

  my $ok = $msg->last_send_successful;
  printf "Attachment $f sent to $to - %s\n", $ok ? 'OK' : 'Failed';
}


