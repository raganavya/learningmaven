#!/bin/sh

# clidir = /root/sas
  
#sas-admin profile set-endpoint "http://10.71.70.8:"

#sas-admin profile toggle-color off
#sas-admin profile set-output fulljson

/root/sas/sas-admin auth login --user parvinder.singh --password 'Puniya@407'
