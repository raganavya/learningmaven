#!/bin/sh

/root/sas/sas-admin auth login --user parvinder.singh --password 'Puniya@407'
/root/sas/sas-admin audit list  
