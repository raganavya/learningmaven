use MIME::Lite;
use Text::Template;
use constant TEST => 1;

sub CC;
sub BCC;

$user = shift || die "no customer name input";
$h = {
  customer => $user,
  fullname => 'Parvinder Singh',
  position => 'DevOps Engineer, DCS DAC Service Management',
  mobileno => '0424260705',
  mailaddr => 'parvinder.singh@customerservice.nsw.gov.au',
};

my $template = Text::Template->new(SOURCE => '/home/parvinder.singh/sas/email-temp.tml')
  or die "Couldn't construct template: $Text::Template::ERROR";

$content = $template->fill_in(HASH => $h) ||
  die "Couldn't fill in template: $Text::Template::ERROR";

$tt = {
  jl => 'Jane.Leung@facs.nsw.gov.au',
  hj => 'Hassan.Jaffri@facs.nsw.gov.au',
  ps => 'parvinder.singh@customerservice.nsw.gov.au',
  ds => 'Alexandra.Peattie@customerservice.nsw.gov.au',
  in => 'Indu.Neelakandan@customerservice.nsw.gov.au',
  az => 'Angela.Zinn1@customerservice.nsw.gov.au',
  sh => 'Simon.Herbert@customerservice.nsw.gov.au',
  dc => 'dacsupport@customerservice.nsw.gov.au',
  ad => 'Ankit.Darji@customerservice.nsw.gov.au',
  tv => 'tulika.varshney@customerservice.nsw.gov.au',
};

my $from = $tt->{'dc'};

@file = (
  "/home/parvinder.singh/sas/sasweeklyreport.csv",
);
$to = $tt->{'jl'};
$cc = CC;
$bcc = BCC;

if (TEST) {
  print "TEST Mode (disabled CC and BCC):\nBCC: $bcc\n";
  $bcc = '';
}

my $msg = MIME::Lite->new(
  From    => $from,
  To      => $to,
  Cc      => $cc,
  Bcc      => $bcc,
  Subject => 'Okta report',
  Type    => 'text/html',
  Data    => "$content\n", 
);
$msg->attach(
  Type => 'image/jpg',
  Id   => 'logo.jpg',
  Path => '/home/azureuser/logo.jpg',
);
foreach $file (@file) {
  print "attaching $file...\n";
  $msg->attach(
    Path    => $file,
    Type    =>'application/csv'
  );
}
MIME::Lite->send('smtp', 'localhost', Timeout=>60);
$msg->send;
print "sent to $to\n";

# address array to string with comma
sub a2s {
  return join ',', map { $tt->{$_} } @_;
}

sub CC {
  return a2s qw/ hj ds /;
}

sub BCC {
  return a2s qw / ps jc /;
}

__DATA__

