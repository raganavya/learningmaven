#!/bin/sh
/root/sas/sas-admin audit list  
