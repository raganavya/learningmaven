#!/bin/sh

/root/sas/sas-admin audit list --after "$(date "--date=$(date) -7 day" +%F)"
