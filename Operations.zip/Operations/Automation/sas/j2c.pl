#!/usr/bin/perl

use strict;
use JSON;
use Data::Dumper;

my @data = <>;
my $js = join '', @data;
my $j = from_json($js);
my @h = qw/
  user
  action
  application
  state
  timeStamp
/;

print qq(").join('","', map {uc} @h).qq("),"\n";
my $items = $j->{items};

foreach my $h (@$items) {
  my @row;
  foreach my $k (@h) {
    push @row, $h->{$k};
  }
  print qq(").join('","', @row).qq("),"\n";
}

__END__
 'application' => 'SASLogon',
 'timeStamp' => '2020-10-14T00:06:22.356Z',
 'state' => 'success',
 'user' => 'srikanth.kumar',
 'action' => 'SessionDestroyed',

