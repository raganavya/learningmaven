# Last 7 days okta report (Decommissioned)

Last 7 days okta report has been **decommissioned** as the delivery manager do not need the report delivered to their inbox anymore.

For more info: https://nswdac.atlassian.net/browse/DAC-4636