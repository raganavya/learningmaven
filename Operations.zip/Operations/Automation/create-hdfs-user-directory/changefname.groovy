#!/usr/bin/env groovy

regapp="/opt/app/hdfs/rego.yml"
modapp="/opt/app/hdfs/chmod.yml"
ownapp="/opt/app/hdfs/chown.yml"
mvapp="/opt/app/hdfs/mv.yml"
hosts="/opt/app/hdfs/hosts"
ok = '\u2705'
nok = '\u274C'
err = '\u274C'

OwnerVal = "${params.Currentfile}".trim()
FileVal = "${params.Tobefile}".trim()

rego = 3
move = 3
own = 3
regoerr = "Error: HDFS System cannot be registered!"
regok = "HDFS System registered successfully."
ownerr = "Error: HDFS File ownership cannot be changed!"
ownok = "HDFS File ownership changed successfully."
moderr = "Error: HDFS File permission cannot be changed!"
modeok = "DFS File permission changed successfully."
mvapperr = "Error: File name cannot be changed!"
mvappok = "File name  changed successfully."

msg = "Change file name '${OwnerVal}' for '${FileVal}'?"

stage 'Confirm Task'
node() {
    timeout(time: 30, unit: 'SECONDS') {
        input "${msg}"
    }
}

def MsgBox() {
    script {
        if (rego == 0) {
            echo "${ok} ${regok}"
        } else {
            echo "${err} ${regoerr}"
            currentBuild.result = 'ABORTED'
            error(${regoerr})
            sh "exit ${rego}"
        }
        if (own == 0) {
            echo "${ok} ${ownok}"
        } else {
            echo "${err} ${ownerr}"
            currentBuild.result = 'ABORTED'
            error(${ownerr})
            sh "exit ${own}"
        }
        if (move == 0) {
            echo "${ok} ${mvappok}"
        } else {
            echo "${err} ${mvapperr}"
            currentBuild.result = 'ABORTED'
            error(${mvapperr})
            sh "exit ${move}"
        }
    }
}

pipeline {
    agent any
        parameters {
            string(
                name: 'Currentfile',
                defaultValue:"",
                description: "Input the current path of the file!")
            string(
                name: 'Tobefile',
                defaultValue:"",
                description: "Input the change file name with full path! eg. /user/dir1/filename.txt")
    }
    stages {
        stage("Parameter Validation") {
            steps {
                script {
                    if ("${OwnerVal}" == "") {
                        currentBuild.result = 'ABORTED'
                        echo "${err} Invalid Pathname!"
                        error('Error: Invalid path name!')
                        sh 'exit 1'
                    }
                    if ("${FileVal}" == "") {
                        currentBuild.result = 'ABORTED'
                        echo "${err} Invalid File name or path!"
                        error('Error: Invalid File name or path!')
                        sh 'exit 1'
                    }
                    echo "${ok} Parameters validated - PASSED!"
                    currentBuild.result = 'SUCCESS'
                }
            }
        }
        stage("Register to HDFS System") {
            steps {
                script {
                    rego = sh(
                        script: "sudo ansible-playbook -i ${hosts} ${regapp}",
                        returnStatus: true
                    )
                    if (rego != 0) {
                        echo "${err} ${regoerr}"
                        error(${regoerr})
                    } else {
                        echo "${ok} ${regok}"
                    }
                }
            }
        }
        stage("Change the file name") {
            steps {
                script {
                    own = sh(
                        script: "sudo ansible-playbook -i ${hosts} ${mvapp} --extra-vars \"file1='${OwnerVal}' file2='${FileVal}'\"",
                        returnStatus: true
                    )
                    if (own != 0) {
                        echo "${err} ${mvapperr}"
                        error(${mvapperr})
                    } else {
                        echo "${ok} ${mvappok}"
                    }
                }
            }
        }
    }
    post("Post Info") {
        always {
            echo 'File ownership modification is completed'
            echo "old file name is '${OwnerVal}'."
            echo "Current File is '${FileVal}'."
            // cucumber buildStatus: 'UNSTABLE', failedFeaturesNumber: 999, failedScenariosNumber: 999, failedStepsNumber: 3, fileIncludePattern: '**/*.json', skippedStepsNumber: 999
        }
        success {
            echo "${OwnerVal} name had been successfully changed to ${FileVal}"
            MsgBox()
        }
        failure {
            echo "${nok} Change Permission process Failed!"
            MsgBox()
        }
        unstable {
            echo 'This will run only if the run was marked as unstable'
        }
    }
    options {
        timeout(time: 60, unit: 'MINUTES')
    }
}
