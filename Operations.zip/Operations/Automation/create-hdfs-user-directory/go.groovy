#!/usr/bin/env groovy

regapp="/opt/app/hdfs/rego.yml"
modapp="/opt/app/hdfs/chmod.yml"
ownapp="/opt/app/hdfs/chown.yml"
hosts="/opt/app/hdfs/hosts"
ok = '\u2705'
nok = '\u274C'
err = '\u274C'

OwnerVal = "${params.Owner}".trim()
FileVal = "${params.File}".trim()

rego = 3
own = 3
mode = 3
regoerr = "Error: HDFS System cannot be registered!"
regok = "HDFS System registered successfully."
ownerr = "Error: HDFS File ownership cannot be changed!"
ownok = "HDFS File ownership changed successfully."
moderr = "Error: HDFS File permission cannot be changed!"
modeok = "DFS File permission changed successfully."

msg = "Change owner '${OwnerVal}' for '${FileVal}'?"

stage 'Confirm Task'
node() {
    timeout(time: 30, unit: 'SECONDS') {
        input "${msg}"
    }
}

def MsgBox() {
    script {
        if (rego == 0) {
            echo "${ok} ${regok}"
        } else {
            echo "${err} ${regoerr}"
            currentBuild.result = 'ABORTED'
            error(${regoerr})
            sh "exit ${rego}"
        }
        if (own == 0) {
            echo "${ok} ${ownok}"
        } else {
            echo "${err} ${ownerr}"
            currentBuild.result = 'ABORTED'
            error(${ownerr})
            sh "exit ${own}"
        }
        if (mode == 0) {
            echo "${ok} ${modeok}"
        } else {
            echo "${err} ${moderr}"
            currentBuild.result = 'ABORTED'
            error(${moderr})
            sh "exit ${mode}"
        }
    }
}

pipeline {
    agent any
        parameters {
            string(
                name: 'Owner',
                defaultValue:"",
                description: "Input the ownership of the file!")
            string(
                name: 'File',
                defaultValue:"",
                description: "Input the file name with full path! eg. /user/dir1/filename.txt")
    }
    stages {
        stage("Parameter Validation") {
            steps {
                script {
                    if ("${OwnerVal}" == "") {
                        currentBuild.result = 'ABORTED'
                        echo "${err} Invalid Ownership!"
                        error('Error: Invalid owner name!')
                        sh 'exit 1'
                    }
                    if ("${FileVal}" == "") {
                        currentBuild.result = 'ABORTED'
                        echo "${err} Invalid File name or path!"
                        error('Error: Invalid File name or path!')
                        sh 'exit 1'
                    }
                    echo "${ok} Parameters validated - PASSED!"
                    currentBuild.result = 'SUCCESS'
                }
            }
        }
        stage("Register to HDFS System") {
            steps {
                script {
                    rego = sh(
                        script: "sudo ansible-playbook -i ${hosts} ${regapp}",
                        returnStatus: true
                    )
                    if (rego != 0) {
                        echo "${err} ${regoerr}"
                        error(${regoerr})
                    } else {
                        echo "${ok} ${regok}"
                    }
                }
            }
        }
        stage("Change File Ownership") {
            steps {
                script {
                    own = sh(
                        script: "sudo ansible-playbook -i ${hosts} ${ownapp} --extra-vars \"owner='${OwnerVal}' file='${FileVal}'\"",
                        returnStatus: true
                    )
                    if (own != 0) {
                        echo "${err} ${ownerr}"
                        error(${ownerr})
                    } else {
                        echo "${ok} ${ownok}"
                    }
                }
            }
        }
        stage("Change File Permission") {
            steps {
                script {
                    mode = sh(
                        script: "sudo ansible-playbook -i ${hosts} ${modapp} --extra-vars \"file='${FileVal}'\"",
                        returnStatus: true
                    )
                    if (mode != 0) {
                        echo "${err} ${moderr}"
                        error(${moderr})
                    } else {
                        echo "${ok} ${modeok}"
                    }
                }
            }
        }
    }
    post("Post Info") {
        always {
            echo 'File ownership modification is completed'
            echo "Owner is '${OwnerVal}'."
            echo "File is '${FileVal}'."
            // cucumber buildStatus: 'UNSTABLE', failedFeaturesNumber: 999, failedScenariosNumber: 999, failedStepsNumber: 3, fileIncludePattern: '**/*.json', skippedStepsNumber: 999
        }
        success {
            echo "${FileVal} permission had been successfully changed to ${OwnerVal}"
            MsgBox()
        }
        failure {
            echo "${nok} Change Permission process Failed!"
            MsgBox()
        }
        unstable {
            echo 'This will run only if the run was marked as unstable'
        }
    }
    options {
        timeout(time: 60, unit: 'MINUTES')
    }
}

