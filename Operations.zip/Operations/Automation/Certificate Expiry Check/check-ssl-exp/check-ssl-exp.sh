#!/bin/sh

while IFS=',' read -r APP URL PORT; do
	# [ -z $APP ] && echo "no Website found" && exit
	[ -z $URL ] && echo "no URL found" && exit
	[ -z $PORT ] && PORT=443

	# echo "echo | openssl s_client -servername $URL -connect $URL:$PORT 2>/dev/null | openssl x509 -noout -issuer -subject -dates"
	echo "------- $APP: https://$URL:$PORT --------"
	echo | openssl s_client -servername $URL -connect $URL:$PORT 2>/dev/null | openssl x509 -noout -issuer -subject -dates
	echo
done < foo-app-list
