#!/usr/bin/env groovy

repoURL="https://github.com/NSWDAC/Platform.git"
appdir='./Operations/Jenkins Tools/create-orch-keytab'
playbook="playbook.yml"
hosts="hosts"
branch = "master"

ok = '\u2705'
nok = '\u274C'
err = '\u274C'

UserVal = "${params.User}".trim()
PassVal = "${params.Pass}".trim()

rego = 3
own = 3
mode = 3
regoerr = "Error: HDFS System cannot be registered!"
modeok = "DFS File permission changed successfully."

msg = "Username: '${UserVal}', Password: '${PassVal}'?"

stage 'Confirm Task'
node() {
    timeout(time: 30, unit: 'SECONDS') {
        input "${msg}"
    }
}
stage 'Git Update'
node() {
    git url: repoURL, credentialsId: "dac2018", branch: branch
    sh "cd '${appdir}'; ls -ltrhR"
    // sh "ls -ltrhR"
}


def MsgBox() {
    script {
        echo "${ok} ${msg}"
    }
}

pipeline {
    agent any
        parameters {
            string(
                name: 'User',
                defaultValue:"",
                description: "Input the Username created in Active Directory!")
            string(
                name: 'Pass',
                defaultValue:"",
                description: "Input the Password created in Active Directory!")
    }
    stages {
        stage("Parameter Validation") {
            steps {
                script {
                    if ("${UserVal}" == "") {
                        currentBuild.result = 'ABORTED'
                        echo "${err} Invalid Username!"
                        error('Error: Invalid Username!')
                        sh 'exit 1'
                    }
                    if ("${PassVal}" == "") {
                        currentBuild.result = 'ABORTED'
                        echo "${err} Invalid Username!"
                        error('Error: Invalid Username!')
                        sh 'exit 1'
                    }
                    echo "${ok} Parameters validated - PASSED!"
                    currentBuild.result = 'SUCCESS'
                }
            }
        }
        stage("Generate Orch Keytab File") {
            steps {
                sh "cd '${appdir}'; sudo ansible-playbook -i ${hosts} ${playbook} -e 'password=${PassVal} username=${UserVal}' -vvv"
            }
        }
    }
    post("Post Info") {
        always {
            echo 'Keytab created and transferred to Orch Server'
            echo "Username is '${UserVal}'."
            echo "Password is '${PassVal}'."
        }
        success {
            echo "${UserVal} permission had been successfully changed to ${PassVal}"
            MsgBox()
        }
        failure {
            echo "${nok} Change Permission process Failed!"
            MsgBox()
        }
        unstable {
            echo 'This will run only if the run was marked as unstable'
        }
    }
    options {
        timeout(time: 60, unit: 'MINUTES')
    }
}

