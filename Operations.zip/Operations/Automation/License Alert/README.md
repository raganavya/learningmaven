# license-alarm-tool
An Lite Alarm for License Management
