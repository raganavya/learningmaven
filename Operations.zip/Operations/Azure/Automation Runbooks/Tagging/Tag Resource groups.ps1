#
#   Author: Damien Smith
#   Date:   25/09/2019
#   Code:   Powershell
#   Goal:   Using Azure Cloud command line (with appropriate permissions):
#           - For subscription context
#           - apply inputted tags to all resource groups
#

#get subscription id
$SubscriptionId5 = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

# Set context
Set-AzureRmContext -SubscriptionId $SubscriptionId

# Resource Groups

	#List the names of all the Resource groups within the Subscription
	$resourcegroups = Get-AzureRmResourceGroup 
    $resourcename = $resourcegroups | Select-Object -ExpandProperty ResourceGroupName
    
  # Tags you want to apply  
    $RGTagFinal = @{Cluster="NSWDCS"; BusinessUnit="DAC"; Project="Platform2020"; Bau="1"; Layer="process"}
    
	#For each Resource group name apply the Tag of the Resource Group
	$i = -1
    Foreach ($resource in $resourcename)
	{		
        $i = $i + 1
        $name = [string]$resourcename[$i]
        $azureRGinfo = Get-AzureRmResourceGroup -Name $name
        Set-AzureRmResourceGroup -Id $azureRGInfo.ResourceId -Tag $RGTagFinal
        $i
	}
