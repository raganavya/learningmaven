#
#   Author: Damien Smith
#   Date:   25/09/2019
#   Code:   Powershell
#   Goal:   Using Azure Cloud command line (with appropriate permissions):
#           - For subscription context
#           - apply the same tags to all resources in a resource group
#           - this will apply the same tags attached to a resource group to each of its resources
#

#get subscription id
$SubscriptionId = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

# Set context
Set-AzureRmContext -SubscriptionId $SubscriptionId

#List all Resources within the Subscription
	$resourcegroups = Get-AzureRmResourceGroup 
    $resourcename = $resourcegroups | Select-Object -ExpandProperty ResourceGroupName

#For each Resource apply the Tag of the Resource Group
	$i = -1      
    Foreach ($resource in $resourcename)
	{		
        $i = $i + 1
        $name = [string]$resourcename[$i]
        $group = Get-AzureRmResourceGroup $name
    
    if ($null -ne $group.Tags) 
    {
        $resources = Get-AzureRmResource -ResourceGroupName $group.ResourceGroupName
    
    foreach ($r in $resources)
    {
        $resourcetags = (Get-AzureRmResource -ResourceId $r.ResourceId).Tags
        if ($resourcetags)
        {
            foreach ($key in $group.Tags.Keys)
            {
                if (-not($resourcetags.ContainsKey($key)))
                {
                    $resourcetags.Add($key, $group.Tags[$key])
                }
            }
            Set-AzureRmResource -Tag $resourcetags -ResourceId $r.ResourceId -Force
        }
        else
        {
            Set-AzureRmResource -Tag $group.Tags -ResourceId $r.ResourceId -Force
        }
    }
}
}
