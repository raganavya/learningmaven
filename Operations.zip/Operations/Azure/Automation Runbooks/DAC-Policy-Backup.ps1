#
#   Author: Damien Smith
#   Date:   13/08/2019
#   Goal:   Backup the following items:
#           - User role assignments
#           - Network Security Groups
#           - Application Security Groups
#
#   Powershell script for Azure Automation runas account
# ____________________________________________________
# Connect to RunAsAccount
$connectionName = "AzureRunAsConnection"
$servicePrincipalConnection=Get-AutomationConnection -Name $connectionName 
"Logging in to Azure..."
Add-AzureRmAccount -ServicePrincipal -TenantId $servicePrincipalConnection.TenantId -ApplicationId $servicePrincipalConnection.ApplicationId -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint

# ____________________________________________________
# Set Sydney time & Date strings
$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

# ____________________________________________________
# Set Output
cd \temp
$output = ('\temp\DAC-PolicyBackup '+ $datestring2 + '.txt')
if (Test-Path -Path $output) {rm -Force $output}

#___________________________________________________________________________
#PRODUCTION
$SubscriptionId3 = '1e4d857b-9767-4d94-84cc-da027d4371c8'
Set-AzureRMContext -SubscriptionId $SubscriptionId3

# Users Roles - note: this requirement was removed due to it needing Azure Active Directory membership to be given to the automation account
#                     this has been deemed too high level of power.
#[scriptblock]$commandroles = {Get-AzureRMRoleAssignment -Scope ("/subscriptions/" + $SubscriptionId3)  | Format-List}
#$roles = $commandroles.InvokeReturnAsIs() | Out-String

# Network Security Groups
[scriptblock]$commandnsg = {get-AzureRmNetworksecuritygroup  | Format-List}
$nsgs = $commandnsg.InvokeReturnAsIs() | Out-String

# Application Security Groups
[scriptblock]$commandasg = {Get-AzureRmApplicationSecurityGroup  | Format-List}
$asgs = $commandasg.InvokeReturnAsIs() | Out-String

#$output = ("Production Roles: `n -----------------`n" + $roleconfig + "`nProduction NSG Config: `n -----------------`n" + $nsgs + "`nProduction ASG Config: `n -----------------`n" + $asgs)
$output = ("`nProduction NSG Config: `n -----------------`n" + $nsgs + "`nProduction ASG Config: `n -----------------`n" + $asgs)

# print output in cmd
("`n" + "DAC Azure Policy Backup " + $datestring + "`n")
$output

#___________________________________________________________________________
# NON PRODUCTION
$SubscriptionId2 = '7e3a186c-57f5-4b5c-b1d5-02f5ee54da94'
Set-AzureRMContext -SubscriptionId $SubscriptionId2

# Users Roles
#[scriptblock]$commandroles = {Get-AzureRMRoleAssignment -Scope ("/subscriptions/" + $SubscriptionId2)  | Format-List}
#$roles = $commandroles.InvokeReturnAsIs() | Out-String

# Network Security Groups
[scriptblock]$commandnsg = {get-AzureRmNetworksecuritygroup  | Format-List}
$nsgs = $commandnsg.InvokeReturnAsIs() | Out-String

# Application Security Groups
[scriptblock]$commandasg = {Get-AzureRmApplicationSecurityGroup  | Format-List}
$asgs = $commandasg.InvokeReturnAsIs() | Out-String

#$output = ("Non-Production Roles: `n -----------------`n" + $roleconfig + "`n Non-Production NSG Config: `n -----------------`n" + $nsgs + "`n Non-Production ASG Config: `n -----------------`n" + $asgs)
$output = ("`n Non-Production NSG Config: `n -----------------`n" + $nsgs + "`n Non-Production ASG Config: `n -----------------`n" + $asgs)

#___________________________________________________________________________
# CREATE FILE
cd /temp
rm *.txt
$FileName = ('DAC-Config-Backup-'+ $datestring2 +'.txt')
# if (IsNotNullOrEmpty($Filename)) {rm $FileName}
$File = New-Item -Path $FileName -ItemType File 
("`n" + "DAC Azure Policy Backup " + $datestring + "`n") > $File
$output >> $File

#___________________________________________________________________________
# STORE IN BLOB
# set the context to the same subscription as the storage account
#$SubscriptionId3 = '6e4f4fb0-999a-4dc0-9397-f47f358d9b35'
Set-AzureRMContext -SubscriptionId $SubscriptionId3

# Blob details
$ContainerName  = 'dac-azureconfigbackup-container'
$Blob = 'azure-config'
$StorageAccountName = "dacblobbackup"
$ResourceGroup      = "dac-backup-rg"

# Get key to storage account
$acctKey = (Get-AzureRmStorageAccountKey -Name $StorageAccountName -ResourceGroupName $ResourceGroup).Value[0]

# Get Storage Context
$StorageContext = New-AzureStorageContext $StorageAccountName -StorageAccountKey $acctKey

#Copy the file to the storage account
Set-AzureStorageBlobContent -Container $ContainerName -File $File -Blob $FileName -Context $StorageContext -Force

#___________________________________________________________________________
# END
"Production & Non-Production config backup created."

#
# $StorageAccountKey = "UAC1y4+yI+1b+SOU8rQthqQjJNMF5Agl+va3mswJgnWNG1hg6SCyu9ui/j+d7rHvr2aLQYb0fTiVmMZuOM3XpA==" #Get-AzureStorageKey -StorageAccountName $StorageAccountName
# $StorageContext = New-AzureStorageContext $StorageAccountName -StorageAccountKey $StorageAccountKey
# $StorageContext = Set-AzureRmCurrentStorageAccount -ResourceGroupName $StorageAccountName -Name $StorageAccountName

