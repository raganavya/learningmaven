<<<<<<< HEAD


$connectionName = "AzureRunAsConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$startDate = $($now.Date.AddDays(-30))
$endDate = $($now.Date)
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

cd \temp
$output = ('\temp\DAC-ExpiredKeys '+ $datestring2 + '.xlsx')

# Params - VaultName, KeyVersions, SecretVersion, AlertBeforeDays
$VaultName = 'DACKeyVault'
$IncludeAllKeyVersions = $true
$IncludeAllSecretVersions = $true
$AlertBeforeDays = 7

# Get Keys (flag to specify all versions)
   
# Convert keys common model of Object (Id, Name, Version,Expiry, Enabled)

Function New-KeyVaultObject
{
    param
    (
        [string]$Id,
        [string]$Name,
        [string]$Version,
        [System.Nullable[DateTime]]$Expires
    )

    $server = New-Object -TypeName PSObject
    $server | Add-Member -MemberType NoteProperty -Name Id -Value $Id
    $server | Add-Member -MemberType NoteProperty -Name Name -Value $Name
    $server | Add-Member -MemberType NoteProperty -Name Version -Value $Version
    $server | Add-Member -MemberType NoteProperty -Name Expires -Value $Expires
    
    return $server
}

function Get-AzureKeyVaultObjectKeys
{
  param
  (
   [string]$VaultName,
   [bool]$IncludeAllVersions
  )

  $vaultObjects = [System.Collections.ArrayList]@()
  $allKeys = Get-AzureKeyVaultKey -VaultName $VaultName
  foreach ($key in $allKeys) {
    if($IncludeAllVersions){
     $allSecretVersion = Get-AzureKeyVaultKey -VaultName $VaultName -IncludeVersions -Name $key.Name
     foreach($key in $allSecretVersion){
         $vaultObject = New-KeyVaultObject -Id $key.Id -Name $key.Name -Version $key.Version -Expires $key.Expires
         $vaultObjects.Add($vaultObject)
     }
     
    } else {
      $vaultObject = New-KeyVaultObject -Id $key.Id -Name $key.Name -Version $key.Version -Expires $key.Expires
      $vaultObjects.Add($vaultObject)
    }
  }
  
  return $vaultObjects
}

function Get-AzureKeyVaultObjectSecrets
{
  param
  (
   [string]$VaultName,
   [bool]$IncludeAllVersions
  )

  $vaultObjects = [System.Collections.ArrayList]@()
  $allSecrets = Get-AzureKeyVaultSecret -VaultName $VaultName
  foreach ($secret in $allSecrets) {
    if($IncludeAllVersions){
     $allSecretVersion = Get-AzureKeyVaultSecret -VaultName $VaultName -IncludeVersions -Name $secret.Name
     foreach($secret in $allSecretVersion){
         $vaultObject = New-KeyVaultObject -Id $secret.Id -Name $secret.Name -Version $secret.Version -Expires $secret.Expires
         $vaultObjects.Add($vaultObject)
     }
     
    } else {
      $vaultObject = New-KeyVaultObject -Id $secret.Id -Name $secret.Name -Version $secret.Version -Expires $secret.Expires
      $vaultObjects.Add($vaultObject)
    }
  }
  
  return $vaultObjects
}

$allKeyVaultObjects = [System.Collections.ArrayList]@()
$allKeyVaultObjects.AddRange((Get-AzureKeyVaultObjectKeys -VaultName $VaultName -IncludeAllVersions $IncludeAllKeyVersions))
$allKeyVaultObjects.AddRange((Get-AzureKeyVaultObjectSecrets -VaultName $VaultName -IncludeAllVersions $IncludeAllSecretVersions))


# Get expired Objects
$today = (Get-Date).Date  #(Get-Date -Year 2022 -Month 1 -Day 18)
$expiredKeyVaultObjects = [System.Collections.ArrayList]@()
foreach($vaultObject in $allKeyVaultObjects){
if($vaultObject.Expires -and $vaultObject.Expires.AddDays(-$AlertBeforeDays).Date -lt $today)
{
  # add to expiry list
  $expiredKeyVaultObjects.Add($vaultObject) | Out-Null
  Write-Output "Expiring" $vaultObject.Id
}
}


if ($expiredKeyVaultObjects)
{
$expiredKeyVaultObjects| Export-Excel -path $output -WorksheetName "DAC-Expiring-Keys"

#SEND EMAIL With expired key Attachment

$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "azure_49fb67e4a383d154e0d0ae347f41f2cb@azure.com"
$emailSmtpPass = "Password123!"
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "Azure Cloud <do.not.reply@azure.com>"
$emailMessage.To.Add( "<Parvinder.Singh@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Damien.Smith@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Joe.Chiu@customerservice.nsw.gov.au>")
$emailMessage.Subject = ("DAC Key Expiry " + $datestring)
$emailMessage.IsBodyHtml = $true
$emailMessage.Body = 
@"
<p>Please find attached DAC Azure Vault Keys that will expire within 7 days.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );
 
$attachment1 = new-object Net.Mail.Attachment($output)

$emailMessage.Attachments.Add($attachment1)

$SMTPClient.Send($emailMessage)
}
else
{
#SEND EMAIL stating key expiry dates have been checked.

$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "azure_49fb67e4a383d154e0d0ae347f41f2cb@azure.com"
$emailSmtpPass = "Password123!"
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "Azure Cloud <do.not.reply@azure.com>"
$emailMessage.To.Add( "<Parvinder.Singh@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Damien.Smith@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Joe.Chiu@customerservice.nsw.gov.au>")
$emailMessage.Subject = ("DAC Key Expiry " + $datestring)
$emailMessage.IsBodyHtml = $true
$emailMessage.Body = 
@"
<p>Please be advised that no DAC Azure Vault Keys will expire within 7 days.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );

$SMTPClient.Send($emailMessage)

}

=======


$connectionName = "AzureRunAsConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$startDate = $($now.Date.AddDays(-30))
$endDate = $($now.Date)
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

cd \temp
$output = ('\temp\DAC-ExpiredKeys '+ $datestring2 + '.xlsx')
# Params - VaultName, KeyVersions, SecretVersion, AlertBeforeDays
$VaultName = 'DACKeyVault'
$IncludeAllKeyVersions = $true
$IncludeAllSecretVersions = $true
$AlertBeforeDays = 7

# Get Keys (flag to specify all versions)
   
# Convert keys common model of Object (Id, Name, Version,Expiry, Enabled)

Function New-KeyVaultObject
{
    param
    (
        [string]$Id,
        [string]$Name,
        [string]$Version,
        [System.Nullable[DateTime]]$Expires
    )

    $server = New-Object -TypeName PSObject
    $server | Add-Member -MemberType NoteProperty -Name Id -Value $Id
    $server | Add-Member -MemberType NoteProperty -Name Name -Value $Name
    $server | Add-Member -MemberType NoteProperty -Name Version -Value $Version
    $server | Add-Member -MemberType NoteProperty -Name Expires -Value $Expires
    
    return $server
}

function Get-AzureKeyVaultObjectKeys
{
  param
  (
   [string]$VaultName,
   [bool]$IncludeAllVersions
  )

  $vaultObjects = [System.Collections.ArrayList]@()
  $allKeys = Get-AzureKeyVaultKey -VaultName $VaultName
  foreach ($key in $allKeys) {
    if($IncludeAllVersions){
     $allSecretVersion = Get-AzureKeyVaultKey -VaultName $VaultName -IncludeVersions -Name $key.Name
     foreach($key in $allSecretVersion){
         $vaultObject = New-KeyVaultObject -Id $key.Id -Name $key.Name -Version $key.Version -Expires $key.Expires
         $vaultObjects.Add($vaultObject)
     }
     
    } else {
      $vaultObject = New-KeyVaultObject -Id $key.Id -Name $key.Name -Version $key.Version -Expires $key.Expires
      $vaultObjects.Add($vaultObject)
    }
  }
  
  return $vaultObjects
}

function Get-AzureKeyVaultObjectSecrets
{
  param
  (
   [string]$VaultName,
   [bool]$IncludeAllVersions
  )

  $vaultObjects = [System.Collections.ArrayList]@()
  $allSecrets = Get-AzureKeyVaultSecret -VaultName $VaultName
  foreach ($secret in $allSecrets) {
    if($IncludeAllVersions){
     $allSecretVersion = Get-AzureKeyVaultSecret -VaultName $VaultName -IncludeVersions -Name $secret.Name
     foreach($secret in $allSecretVersion){
         $vaultObject = New-KeyVaultObject -Id $secret.Id -Name $secret.Name -Version $secret.Version -Expires $secret.Expires
         $vaultObjects.Add($vaultObject)
     }
     
    } else {
      $vaultObject = New-KeyVaultObject -Id $secret.Id -Name $secret.Name -Version $secret.Version -Expires $secret.Expires
      $vaultObjects.Add($vaultObject)
    }
  }
  
  return $vaultObjects
}

$allKeyVaultObjects = [System.Collections.ArrayList]@()
$allKeyVaultObjects.AddRange((Get-AzureKeyVaultObjectKeys -VaultName $VaultName -IncludeAllVersions $IncludeAllKeyVersions))
$allKeyVaultObjects.AddRange((Get-AzureKeyVaultObjectSecrets -VaultName $VaultName -IncludeAllVersions $IncludeAllSecretVersions))


# Get expired Objects
$today = (Get-Date).Date  #(Get-Date -Year 2022 -Month 1 -Day 18)
$expiredKeyVaultObjects = [System.Collections.ArrayList]@()
foreach($vaultObject in $allKeyVaultObjects){
if($vaultObject.Expires -and $vaultObject.Expires.AddDays(-$AlertBeforeDays).Date -lt $today)
{
  # add to expiry list
  $expiredKeyVaultObjects.Add($vaultObject) | Out-Null
  Write-Output "Expiring" $vaultObject.Id
}
}


if ($expiredKeyVaultObjects)
{
$expiredKeyVaultObjects| Export-Excel -path $output -WorksheetName "DAC-Expiring-Keys"

#SEND EMAIL With expired key Attachment

$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "azure_49fb67e4a383d154e0d0ae347f41f2cb@azure.com"
$emailSmtpPass = "Password123!"
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "Azure Cloud <do.not.reply@azure.com>"
$emailMessage.To.Add( "<Parvinder.Singh@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Damien.Smith@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Joe.Chiu@customerservice.nsw.gov.au>")
$emailMessage.Subject = ("DAC Key Expiry " + $datestring)
$emailMessage.IsBodyHtml = $true
$emailMessage.Body = 
@"
<p>Please find attached DAC Azure Vault Keys that will expire within 7 days.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );
 
$attachment1 = new-object Net.Mail.Attachment($output)

$emailMessage.Attachments.Add($attachment1)

$SMTPClient.Send($emailMessage)
}
else
{
#SEND EMAIL stating key expiry dates have been checked.

$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "azure_49fb67e4a383d154e0d0ae347f41f2cb@azure.com"
$emailSmtpPass = "Password123!"
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "Azure Cloud <do.not.reply@azure.com>"
$emailMessage.To.Add( "<Parvinder.Singh@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Damien.Smith@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Joe.Chiu@customerservice.nsw.gov.au>")
$emailMessage.Subject = ("DAC Key Expiry " + $datestring)
$emailMessage.IsBodyHtml = $true
$emailMessage.Body = 
@"
<p>Please be advised that no DAC Azure Vault Keys will expire within 7 days.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );

$SMTPClient.Send($emailMessage)

}

>>>>>>> 52617cd5f1f433ca62eab463a53715238a3daa38
