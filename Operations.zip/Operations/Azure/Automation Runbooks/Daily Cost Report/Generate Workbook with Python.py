#
# Python Script
# Author: Damien Smith
# Goal:
# when exploring options to generate a Excel workbook (through Azure Automation)
# I played with the idea of using python


from pandas import ExcelWriter
import glob
import os
import pandas as pd

from datetime import date
today = date.today()
d1 = today.strftime("%d%m%Y")

reader = ExcelWriter("DAC-AzureUsageCostReport " + d1 + ".xlsx", engine= 'xlsxwriter')
writer = ExcelWriter("AzrCostRep " + d1 + ".xlsx", engine= 'xlsxwriter')

excel_file = pd.ExcelFile(reader)
for sheet_name in excel_file.sheet_names:
        df = pd.read_excel(reader, sheet_name=sheet_name)
        df.to_excel(reader, sheet_name, index=False)
        worksheet = reader.sheets[sheet_name]
        worksheet.conditional_format('B1:B40',{'type':'3_color_scale','min_color': "#00ff00",'mid_color': '#ffff00' ,'max_color': "#ff0000",})

dfprod = pd.read_excel(reader, sheet_name='Prod')
dfnonprod = pd.read_excel(reader, sheet_name='NonProd')
dfsand = pd.read_excel(reader, sheet_name='Sandbox')
dfdac1 = pd.read_excel(reader, sheet_name='DACsub')
dfdac2 = pd.read_excel(reader, sheet_name='DACsub2')

df = pd.DataFrame({'PRODUCTION': [],
                   'NONPRODUCTION': [],
                   'SANDBOX': [],
                   'DACSub': [],
                   'DACSub2': []})
df['PRODUCTION'] = dfprod.sum(numeric_only=True, axis=0)
df['NONPRODUCTION'] = dfnonprod.sum(numeric_only=True, axis=0)
df['SANDBOX'] = dfsand.sum(numeric_only=True, axis=0)
df['DACSub']  = dfdac1.sum(numeric_only=True, axis=0)
df['DACSub2'] = dfdac2.sum(numeric_only=True, axis=0)

df['PRODUCTION'].T
df['NONPRODUCTION'].T
df['SANDBOX'].T
df['DACSub'].T
df['DACSub2'].T
df.T

df.to_excel(writer, 'Summary', index=False)

writer.save()
