#
# Powershell Script
# Author: Damien Smith
# Date:   01/06/2019
# Goal:   Generate excel workbook with total subscription costs and subscriptions costs by resource
# ____________________________________________________
# Connect to RunAsAccount
$Conn = Get-AutomationConnection -Name AzureRunAsConnection
Connect-AzureRmAccount -ServicePrincipal -Tenant $Conn.TenantID -ApplicationId $Conn.ApplicationID -CertificateThumbprint $Conn.CertificateThumbprint | Out-Null

if ([string]::IsNullOrEmpty($(Get-AzureRmContext).Account)) {Login-AzureRmAccount}


# ____________________________________________________
# Set Sydney time & Date strings
$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$startDate = $($now.Date.AddDays(-30))
$endDate = $($now.Date)
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

cd \temp
$output = ('\temp\DAC-AzureUsageCostReport '+ $datestring2 + '.xlsx')
if (Test-Path -Path $output) {rm -Force $output}

#___________________________________________________________________________
#PRODUCTION
# Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId3 = '1e4d857b-9767-4d94-84cc-da027d4371c8'
# Login-AzureRmAccount -SubscriptionId $SubscriptionId3 -TenantId '5d7c290e-7a76-4d76-bd56-7b92a873f6be'
Set-AzureRmContext -SubscriptionId $SubscriptionId3
# Set-AzContext -SubscriptionId $SubscriptionId3

#Enable-AzureRmAlias

#OUTPUT RAW
$SubConsumptionUsage = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawProd = ( '4.RAWProdAzureCosts.xlsx')

$Prod = ('1.DACProductionUsageCosts.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId3
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups1 = @()
 
foreach ($line in $SubConsumptionUsage) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups1.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups1 += $resourceGroupName
}
}
}
 
$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups1) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsage | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups1[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups1[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups1.Cost


#___________________________________________________________________________
#NON PRODUCTION
#Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId2 = '7e3a186c-57f5-4b5c-b1d5-02f5ee54da94'
Set-AzureRmContext -SubscriptionId $SubscriptionId2
#Set-AzContext -SubscriptionId $SubscriptionId2

#Enable-AzureRmAlias

# Login-AzureRmAccount -SubscriptionId $SubscriptionId2 -TenantId '1ef97a68-e8ab-44ed-a16d-b579fe2d7cd8'

#OUTPUT RAW
$SubConsumptionUsageN = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawNonProd = ( '5.RAWNonProdAzureCosts.xlsx')

$nonProd = ('2.NonProductionUsageCosts.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId2
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups2 = @()
 
foreach ($line in $SubConsumptionUsageN) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups2.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups2 += $resourceGroupName
}
}
}
 
$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups2) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsageN | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups2[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups2[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups2.Cost


#___________________________________________________________________________
#SANDBOX
# Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId = '6e4f4fb0-999a-4dc0-9397-f47f358d9b35'
Set-AzureRmContext -SubscriptionId $SubscriptionId
#Set-AzContext -SubscriptionId $SubscriptionId

#Enable-AzureRmAlias

#OUTPUT RAW
$SubConsumptionUsageR = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawSandbox = ('6.RAWSANDBOXAzureCosts.xlsx')
# $SubConsumptionUsage | Export-Csv -path $RawSandbox


$sandbox = ('3.Sandbox.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups3 = @()
 
foreach ($line in $SubConsumptionUsageR) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups3.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups3 += $resourceGroupName
}
}
}
 
$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups3) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsageR | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups3[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups3[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups3.Cost

#___________________________________________________________________________
# Data Analytics Centre Subscription__
# Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId4 = 'cd94675a-afb9-407a-b9e0-7ec6ad010592'
Set-AzureRmContext -SubscriptionId $SubscriptionId4
#Set-AzContext -SubscriptionId $SubscriptionId4

#Enable-AzureRmAlias

#OUTPUT RAW
$SubConsumptionUsageDac = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawDAC = ('9.RAWDACAzureCosts')
# $SubConsumptionUsage | Export-Csv -path $RawSandbox


$DACsub = ('DACsub.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId4
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups4 = @()
 
foreach ($line in $SubConsumptionUsageDac) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups4.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups4 += $resourceGroupName
}
}
}
 
$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups4) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsageDac | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups4[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups4[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups4.Cost

#___________________________________________________________________________
# Data Analytics Centre Subscription
# Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId5 = 'c91467bb-f444-405f-b9f3-0f4583e9d1ad'
Set-AzureRmContext -SubscriptionId $SubscriptionId5
# Set-AzContext -SubscriptionId $SubscriptionId5

#Enable-AzureRmAlias

#OUTPUT RAW
$SubConsumptionUsageDac2 = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawDACsub2 = ('9.RAWDACAzureCosts')
# $SubConsumptionUsage | Export-Csv -path $RawSandbox


$DACsub2 = ('DACsub2.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId5
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups5 = @()
 
foreach ($line in $SubConsumptionUsageDac2) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups5.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups5 += $resourceGroupName
}
}
}
 
$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups5) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsageDac2 | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups5[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups5[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups5.Cost

#___________________________________________________________________________

# GENERATE SUMMARY Excel File

cd \temp

$totalcost1 = ($resourcegroups1 | Measure-Object 'Cost' -Sum).Sum
$totalcost2 = ($resourcegroups2 | Measure-Object 'Cost' -Sum).Sum
$totalcost3 = ($resourcegroups3 | Measure-Object 'Cost' -Sum).Sum
$totalcost4 = ($resourcegroups4 | Measure-Object 'Cost' -Sum).Sum
$totalcost5 = ($resourcegroups5 | Measure-Object 'Cost' -Sum).Sum
$totalcost6 = $totalcost1 + $totalcost2 +$totalcost3 + $totalcost4 + $totalcost5

$Summary = @(@{Subscription="Prod";    Cost=$totalcost1}, @{Subscription="NonProd"; Cost=$totalcost2}, @{Subscription="Sandbox"; Cost=$totalcost3}, @{Subscription="DACsub";  Cost=$totalcost4}, @{Subscription="DACsub2"; Cost=$totalcost5}, @{Subscription="TOTAL"; Cost=$totalcost6}) | % { New-Object object | Add-Member -NotePropertyMembers $_ -PassThru }

$Summary = $Summary | Select-object Subscription, Cost

# Export-Excel worksheets [adds worksheets after summary sheet]
$Summary | Export-Excel -path $output -WorksheetName "Summary"
$resourcegroups1 | Export-Excel -path $output -WorksheetName "Prod" 
$resourcegroups2 | Export-Excel -path $output -WorksheetName "NonProd"
$resourcegroups3 | Export-Excel -path $output -WorksheetName "Sandbox"
$resourcegroups4 | Export-Excel -path $output -WorksheetName "DACsub"
$resourcegroups5 | Export-Excel -path $output -WorksheetName "DACsub2"
$SubConsumptionUsage     | Export-Excel -path $output -WorksheetName "RAWProdCosts"
$SubConsumptionUsageN    | Export-Excel -path $output -WorksheetName "RAWNonProdCosts"
$SubConsumptionUsageR    | Export-Excel -path $output -WorksheetName "RAWSANDBOXCosts"
$SubConsumptionUsageDac  | Export-Excel -path $output -WorksheetName "RAWDACCosts"
$SubConsumptionUsageDac2 | Export-Excel -path $output -WorksheetName "RAWDAC2Costs"


#___________________________________________________________________________

#SEND EMAIL With Attachments

$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "azure_49fb67e4a383d154e0d0ae347f41f2cb@azure.com"
$emailSmtpPass = "Password123!"
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "Azure Cloud <do.not.reply@azure.com>"
$emailMessage.To.Add( "<Simon.Herbert@treasury.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@treasury.nsw.gov.au>" )
$emailMessage.To.Add( "<Manan.Tyagi@treasury.nsw.gov.au>" )
$emailMessage.To.Add( "<Damien.Smith@treasury.nsw.gov.au>" )
$emailMessage.Subject = ("Azure Usage Cost " + $datestring)
$emailMessage.IsBodyHtml = $true
$emailMessage.Body = 
@"
<p>Please find attached Azure DAC Usage cost reports for the last 30 days.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );
 
$attachment1 = new-object Net.Mail.Attachment($output)

$emailMessage.Attachments.Add($attachment1)

$SMTPClient.Send($emailMessage)
