﻿[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

#alternative approach for copying from Azure storage blobs

$ErrorActionPreference = 'stop'
$Tenn = [System.Environment]::GetEnvironmentVariable('AZCOPY_TENANT_ID','machine')
$AppID = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_APPLICATION_ID','machine')

$SourceStorageAccount = "dacblobbackup" # fill the source storage account
$SourceStorageKey = "*KEYS NOT ENABLED*" # fill the source storage key
$DestStorageAccount = "adlstest01" # fill the destination storage account
$DestStorageKey = "*KEYS NOT ENABLED*"  # fill the destination storage key

# should potentially store this somewhere safer
$AADKey = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_CLIENT_SECRET','machine')

$ssAADKey = ConvertTo-SecureString $AADKey -AsPlainText -Force
$psCredential = New-Object System.Management.Automation.PSCredential($AppID, $ssAADKey)
Connect-AzureRmAccount -ServicePrincipal -Credential $psCredential -TenantId $Tenn

$SourceStorageContext = New-AzureStorageContext -StorageAccountName $SourceStorageAccount -UseConnectedAccount
$DestStorageContext = New-AzureStorageContext -StorageAccountName $DestStorageAccount -UseConnectedAccount


# you could pass in specific containers if you wanted.
$Containers = Get-AzureStorageContainer -Context $SourceStorageContext

# you could also define a array of blobs at the $BlobCpyAry variable

foreach($Container in $Containers)
{
    $ContainerName = $Container.Name
    if (!((Get-AzureStorageContainer -Context $DestStorageContext) | Where-Object { $_.Name -eq $ContainerName }))
    {   
        Write-Output "Creating new container $ContainerName"
        New-AzureStorageContainer -Name $ContainerName -Permission Off -Context $DestStorageContext -ErrorAction Stop
    }

    $Blobs = Get-AzureStorageBlob -Context $SourceStorageContext -Container $ContainerName
    $BlobCpyAry = @() #Create array of objects

    #Do the copy of everything
    foreach ($Blob in $Blobs)
    {
       $BlobName = $Blob.Name
       Write-Output "Copying $BlobName from $ContainerName"
       $BlobCopy = Start-CopyAzureStorageBlob -Context $SourceStorageContext -SrcContainer $ContainerName -SrcBlob $BlobName -DestContext $DestStorageContext -DestContainer $ContainerName -DestBlob $BlobName
       $BlobCpyAry += $BlobCopy
    }

    #Check Status
    foreach ($BlobCopy in $BlobCpyAry)
    {
       #Could ignore all rest and just run $BlobCopy | Get-AzureStorageBlobCopyState but I prefer output with % copied
       $CopyState = $BlobCopy | Get-AzureStorageBlobCopyState -WaitForComplete
       $Message = $CopyState.Source.AbsolutePath + " " + $CopyState.Status + " {0:N2}%" -f (($CopyState.BytesCopied/$CopyState.TotalBytes)*100) 
       Write-Output $Message
    }
}