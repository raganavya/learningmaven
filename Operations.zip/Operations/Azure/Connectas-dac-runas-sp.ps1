﻿[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$ClientID = [System.Environment]::GetEnvironmentVariable('USER_MSI_ID','machine')
$uri = 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net&client_id='+$ClientID

# Make an API call to OAuth Token Endpoint to get the token. The endpoint 169.254.169.254 is only routable within azure and azure resources
$Response = Invoke-RestMethod -Uri $uri -Method GET -Headers @{Metadata="true"}

# Extract the Access token from the response
$KeyVaultToken = $Response.access_token

#Get variables from keyvault secrets
# note you can add additional secure variables for other requirements

$Tenn = (Invoke-RestMethod -Uri https://dackeyvault.vault.azure.net/secrets/dac-azure-tenant-id/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value
$AppID = (Invoke-RestMethod -Uri https://dackeyvault.vault.azure.net/secrets/dac-prod-runas-service-account-appid/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value
$AADKey = (Invoke-RestMethod -Uri https://dackeyvault.vault.azure.net/secrets/dac-prod-runas-service-account-secret/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value
$ssAADKey = ConvertTo-SecureString $AADKey -AsPlainText -Force

# connect as Prod 'Run As' Service account
$psCredential = New-Object System.Management.Automation.PSCredential($AppID, $ssAADKey)
Connect-AzAccount -ServicePrincipal -Credential $psCredential -TenantId $Tenn


#Get-AzContext -ListAvailable
#Clear-AzContext