﻿[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
# ____________________________________________________
# Connect to Azure

$Tenn = [System.Environment]::GetEnvironmentVariable('AZCOPY_TENANT_ID','machine')
$AppID = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_APPLICATION_ID','machine')
$AADKey = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_CLIENT_SECRET','machine')

$ssAADKey = ConvertTo-SecureString $AADKey -AsPlainText -Force
$psCredential = New-Object System.Management.Automation.PSCredential($AppID, $ssAADKey)
Connect-AzureRmAccount -ServicePrincipal -Credential $psCredential -TenantId $Tenn


# ____________________________________________________
# Set Sydney time & Date strings
$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$startDate = $($now.Date.AddDays(-30))
$endDate = $($now.Date)
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

#cd C:\temp
$output = ('\temp\DAC-AzureUsageCostReport-'+ $datestring2 + '.xlsx')
if (Test-Path -Path $output) {rm -Force $output}

#___________________________________________________________________________
#PRODUCTION
# Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId3 = [System.Environment]::GetEnvironmentVariable('PROD_SUB','machine')
Set-AzureRmContext -SubscriptionId $SubscriptionId3

#OUTPUT RAW
$SubConsumptionUsage = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
#Resolve-AzureRmError

$RawProd = ( '4.RAWProdAzureCosts.xlsx')

$Prod = ('1.DACProductionUsageCosts.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId3
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups1 = @()
 
foreach ($line in $SubConsumptionUsage) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups1.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups1 += $resourceGroupName
}
}
}

$resourceGroups1 = $resourceGroups1 | where {$_.Name}

$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups1) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsage | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups1[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups1[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups1.Cost


#___________________________________________________________________________
#NON PRODUCTION
#Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId2 = [System.Environment]::GetEnvironmentVariable('NONPROD_SUB','machine')
Set-AzureRmContext -SubscriptionId $SubscriptionId2

#OUTPUT RAW
$SubConsumptionUsageN = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawNonProd = ( '5.RAWNonProdAzureCosts.xlsx')
#Resolve-AzureRmError

$nonProd = ('2.NonProductionUsageCosts.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId2
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups2 = @()
 
foreach ($line in $SubConsumptionUsageN) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups2.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups2 += $resourceGroupName
}
}
}

$resourceGroups2 = $resourceGroups2 | where {$_.Name}

$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups2) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsageN | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups2[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups2[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups2.Cost


#___________________________________________________________________________
#SANDBOX
# Get-AzureRmContext | Remove-AzureRmContext -Force
$SubscriptionId = [System.Environment]::GetEnvironmentVariable('SANDBOX_SUB','machine')
Set-AzureRmContext -SubscriptionId $SubscriptionId

#OUTPUT RAW
$SubConsumptionUsageR = Get-AzureRmConsumptionUsageDetail -StartDate $startDate -EndDate $endDate
$RawSandbox = ('6.RAWSANDBOXAzureCosts.xlsx')
# $SubConsumptionUsage | Export-Csv -path $RawSandbox
#Resolve-AzureRmError

$sandbox = ('3.Sandbox.xlsx')

$SubIdPrefix = "/subscriptions/" + $SubscriptionId
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/"
$resourceGroupName = @()
$resourceGroups3 = @()
 
foreach ($line in $SubConsumptionUsageR) {
if ($line.InstanceId -ne $null ) {
$thisRgName = $($line.InstanceId.ToLower()).Replace($RgIdPrefix.ToLower(),"")
$toAdd = $thisRgName.Split("/")[0]
$toAdd = $toAdd.ToString()
$toAdd = $toAdd.ToLower()
$toAdd = $toAdd.Trim()
 
if ($resourceGroups3.Name -notcontains $toAdd) {
$resourceGroupName = [PSCustomObject]@{
Name = $toAdd
}
$resourceGroups3 += $resourceGroupName
}
}
}


$resourceGroups3 = $resourceGroups3 | where {$_.Name}

$currentResourceGroups = Get-AzureRmResourceGroup
$rgIndexId = 0
 
foreach ($rg in $resourceGroups3) {
#$thisRg = $null
$RgIdPrefix = $SubIdPrefix + "/resourceGroups/" + $rg.Name
$ThisRgCost = $null
$SubConsumptionUsageR | ? { if ( $_.InstanceId -ne $null) { $($_.InstanceId.ToLower()).StartsWith($RgIdPrefix.ToLower()) } } | ForEach-Object { $ThisRgCost += $_.PretaxCost }
$toaddCost = [math]::Round($ThisRgCost,2)
$resourceGroups3[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "Cost" -Value $toaddCost
if ($currentResourceGroups.ResourceGroupName -contains $rg.Name) {
$addingResourceGroup = Get-AzureRmResourceGroup -Name $($rg.Name)
# $resourceGroups3[$rgIndexId] | Add-Member -MemberType NoteProperty -Name "NotifyCostLimit" -Value $($addingResourceGroup.tags.NotifyCostLimit)
}
$rgIndexId ++
}
$ActualCost = $resourcegroups3.Cost


#___________________________________________________________________________

# GENERATE SUMMARY Excel File
'$resourcegroups1.Cost'
'_____________________'
$resourcegroups1.Cost
'$resourcegroups2.Cost'
'_____________________'
$resourcegroups2.Cost
'$resourcegroups3.Cost'
'_____________________'
$resourcegroups3.Cost

'$resourcegroups1.Cost | Measure-Object -Sum'
'_____________________'
$resourcegroups2.Cost | Measure-Object -Sum

'$resourcegroups1.Cost | Measure-Object -Sum'
'_____________________'
$resourcegroups2.Cost | Measure-Object -Sum

'$resourcegroups3.Cost | Measure-Object -Sum'
'_____________________'
$resourcegroups3.Cost | Measure-Object -Sum


$totalcost1 = ($resourcegroups1.Cost | Measure-Object -Sum).Sum
$totalcost2 = ($resourcegroups2.Cost | Measure-Object -Sum).Sum
$totalcost3 = ($resourcegroups3.Cost | Measure-Object -Sum).Sum

if ($totalcost1 -eq 0 -Or $totalcost1.IsNullOrEmpty) {
 '$totalcost1 is still 0!'
 $temp = 0
 $totalcost1 | Foreach { $temp += $_}
 $totalcost1 = $temp
}

if ($totalcost2 -eq 0 -Or $totalcost2.IsNullOrEmpty) {
 '$totalcost2 is still 0!'
 $temp2 = 0
 $totalcost2 | Foreach { $temp2 += $_}
 $totalcost2 = $temp2
}

if ($totalcost3 -eq 0 -Or $totalcost3.IsNullOrEmpty) {
 '$totalcost3 is still 0!'
 $temp3 = 0
 $totalcost3 | Foreach { $temp3 += $_}
 $totalcost3 = $temp3
}

if ($totalcost1 -eq 0 -Or $totalcost1.IsNullOrEmpty) {
 '$totalcost1 is 0!'
 $totalcost1 = ($resourcegroups1 | Measure-Object 'Cost' -Sum).Sum   
}

if ($totalcost2 -eq 0 -Or $totalcost2.IsNullOrEmpty) {
 '$totalcost2 is 0!'
 $totalcost2 = ($resourcegroups2 | Measure-Object 'Cost' -Sum).Sum   
}

if ($totalcost3 -eq 0 -Or $totalcost3.IsNullOrEmpty) {
 '$totalcost3 is 0!'
 $totalcost3 = ($resourcegroups3 | Measure-Object 'Cost' -Sum).Sum   
}


#$totalcost1 = ($resourcegroups1 | Measure-Object 'Cost' -Sum).Sum
#$totalcost2 = ($resourcegroups2 | Measure-Object 'Cost' -Sum).Sum
#$totalcost3 = ($resourcegroups3 | Measure-Object 'Cost' -Sum).Sum
#$totalcost4 = ($resourcegroups4 | Measure-Object 'Cost' -Sum).Sum
#$totalcost5 = ($resourcegroups5 | Measure-Object 'Cost' -Sum).Sum
#$totalcost6 = $totalcost1 + $totalcost2 +$totalcost3 + $totalcost4 + $totalcost5

'Totalcost 1'
'________'
$totalcost1
'________'

'Totalcost 2'
'________'
$totalcost2
'________'

'Totalcost 3'
'________'
$totalcost3
'________'

$totalcost6 = $totalcost1 + $totalcost2 + $totalcost3

'Totalcost 6'
'________'
$totalcost6
'________'


#$Summary = @(@{Subscription="Prod";    Cost=$totalcost1}, @{Subscription="NonProd"; Cost=$totalcost2}, @{Subscription="Sandbox"; Cost=$totalcost3}, @{Subscription="DACsub";  Cost=$totalcost4}, @{Subscription="DACsub2"; Cost=$totalcost5}, @{Subscription="TOTAL"; Cost=$totalcost6}) | % { New-Object object | Add-Member -NotePropertyMembers $_ -PassThru }
$Summary = @(@{Subscription="Prod";    Cost=$totalcost1}, @{Subscription="NonProd"; Cost=$totalcost2}, @{Subscription="Sandbox"; Cost=$totalcost3}, @{Subscription="TOTAL"; Cost=$totalcost6}) | % { New-Object object | Add-Member -NotePropertyMembers $_ -PassThru }

$Summary = $Summary | Select-object Subscription, Cost

# Export-Excel worksheets [adds worksheets after summary sheet]

$Summary | Export-Excel -path $output -WorksheetName "Summary"
$resourcegroups1 | Export-Excel -path $output -WorksheetName "Prod" 
$resourcegroups2 | Export-Excel -path $output -WorksheetName "NonProd"
$resourcegroups3 | Export-Excel -path $output -WorksheetName "Sandbox"
#$resourcegroups4 | Export-Excel -path $output -WorksheetName "DACsub"
#$resourcegroups5 | Export-Excel -path $output -WorksheetName "DACsub2"
$SubConsumptionUsage     | Export-Excel -path $output -WorksheetName "RAWProdCosts"
$SubConsumptionUsageN    | Export-Excel -path $output -WorksheetName "RAWNonProdCosts"
$SubConsumptionUsageR    | Export-Excel -path $output -WorksheetName "RAWSANDBOXCosts"
#$SubConsumptionUsageDac  | Export-Excel -path $output -WorksheetName "RAWDACCosts"
#$SubConsumptionUsageDac2 | Export-Excel -path $output -WorksheetName "RAWDAC2Costs"


#___________________________________________________________________________

#SEND EMAIL With Attachments

$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "apikey"
$emailSmtpPass = [System.Environment]::GetEnvironmentVariable('SMTP_TOKEN','machine')

$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "DAC Support <dacsupport@customerservice.nsw.gov.au>"
$emailMessage.To.Add( "<Simon.Herbert@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Manan.Tyagi@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Damien.Smith@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Jaspreet.Singh@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Preeti.Preeti@customerservice.nsw.gov.au>")
$emailMessage.Subject = ("Azure Usage Cost " + $datestring)
$emailMessage.IsBodyHtml = $true
$emailMessage.Body = 
@"
<p> </p>
<p>Please find attached Azure DAC Usage cost reports for the last 30 days.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );
 
$attachment1 = new-object Net.Mail.Attachment($output)

$emailMessage.Attachments.Add($attachment1)

$SMTPClient.Send($emailMessage)

#
# END
# ____________________________________________________