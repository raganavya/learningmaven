﻿
#   Author: Damien Smith
#   Date:   13/08/2019
#   Goal:   Backup the following items:
#           - Network Security Groups
#           - Application Security Groups
# ____________________________________________________

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# ____________________________________________________
# Set Sydney time & Date strings
$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

# ____________________________________________________
# Set Output
cd \temp
$output = ('\temp\DAC-PolicyBackup '+ $datestring2 + '.txt')
if (Test-Path -Path $output) {rm -Force $output}

#___________________________________________________________________________
#PRODUCTION
$SubscriptionId3 = [System.Environment]::GetEnvironmentVariable('PROD_SUB','machine')
Set-AzureRMContext -SubscriptionId $SubscriptionId3

#[scriptblock]$commandroles = {Get-AzureRMRoleAssignment -Scope ("/subscriptions/" + $SubscriptionId3)  | Format-List}
#$roles = $commandroles.InvokeReturnAsIs() | Out-String

# Network Security Groups
[scriptblock]$commandnsg = {get-AzureRmNetworksecuritygroup  | Format-List}
$nsgs = $commandnsg.InvokeReturnAsIs() | Out-String

# Application Security Groups
[scriptblock]$commandasg = {Get-AzureRmApplicationSecurityGroup  | Format-List}
$asgs = $commandasg.InvokeReturnAsIs() | Out-String

#$output = ("Production Roles: `n -----------------`n" + $roleconfig + "`nProduction NSG Config: `n -----------------`n" + $nsgs + "`nProduction ASG Config: `n -----------------`n" + $asgs)
$output = ("`nProduction NSG Config: `n -----------------`n" + $nsgs + "`nProduction ASG Config: `n -----------------`n" + $asgs)

# print output in cmd
("`n" + "DAC Azure Policy Backup " + $datestring + "`n")
$output

#___________________________________________________________________________
# NON PRODUCTION
$SubscriptionId2 = [System.Environment]::GetEnvironmentVariable('NONPROD_SUB','machine')
Set-AzureRMContext -SubscriptionId $SubscriptionId2

# Users Roles
#[scriptblock]$commandroles = {Get-AzureRMRoleAssignment -Scope ("/subscriptions/" + $SubscriptionId2)  | Format-List}
#$roles = $commandroles.InvokeReturnAsIs() | Out-String

# Network Security Groups
[scriptblock]$commandnsg = {get-AzureRmNetworksecuritygroup  | Format-List}
$nsgs = $commandnsg.InvokeReturnAsIs() | Out-String

# Application Security Groups
[scriptblock]$commandasg = {Get-AzureRmApplicationSecurityGroup  | Format-List}
$asgs = $commandasg.InvokeReturnAsIs() | Out-String

#$output = ("Non-Production Roles: `n -----------------`n" + $roleconfig + "`n Non-Production NSG Config: `n -----------------`n" + $nsgs + "`n Non-Production ASG Config: `n -----------------`n" + $asgs)
$output2 = ("`n Non-Production NSG Config: `n -----------------`n" + $nsgs + "`n Non-Production ASG Config: `n -----------------`n" + $asgs)
$output2

#___________________________________________________________________________
# CREATE FILE
cd /temp
rm *.txt
$FileName = ('DAC-Config-Backup-'+ $datestring2 +'.txt')
# if (IsNotNullOrEmpty($Filename)) {rm $FileName}
$File = New-Item -Path $FileName -ItemType File 
("`n" + "DAC Azure Policy Backup " + $datestring + "`n") > $File
$output >> $File
$output2 >> $File

#___________________________________________________________________________
# STORE IN BLOB
# set the context to the same subscription as the storage account
Set-AzureRMContext -SubscriptionId $SubscriptionId3

# Blob details
$ContainerName  = 'dac-azureconfigbackup-container'
$Blob = 'azure-config'
$StorageAccountName = "dacblobbackup"
$ResourceGroup      = "dac-backup-rg"

# Get key to storage account
$acctKey = (Get-AzureRmStorageAccountKey -Name $StorageAccountName -ResourceGroupName $ResourceGroup).Value[0]

# Get Storage Context
$StorageContext = New-AzureStorageContext $StorageAccountName -StorageAccountKey $acctKey

#Copy the file to the storage account
Set-AzureStorageBlobContent -Container $ContainerName -File $File -Blob $FileName -Context $StorageContext -Force

#___________________________________________________________________________
# END
"Production & Non-Production config backup created."
