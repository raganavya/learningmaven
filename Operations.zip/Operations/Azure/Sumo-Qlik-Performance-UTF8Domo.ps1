﻿
# script grabs last 4 latest modified DataCollector Files and modifies encoding to UTF8-DOM
# checks for equivalent file from 24 hours ago and deletes it if last modified time is less.

$ErrorActionPreference = "continue"
$Path = "E:\sumologs\windows"
$Pathe = "E:\sumologs\windows\encoded"

# Set Sydney time & Date strings
$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$date = $now.ToString("yyyyMMdd-HH00")
$yesterday = $($now.AddHours(-24))
$date2 = $yesterday.ToString("yyyyMMdd-HH00")

$list = Get-ChildItem -Path $Path -Filter *DataCollector*
$sort = $list  | Sort-Object -Property LastWriteTime | Select-Object -Last 4

$sort | ForEach-Object {
    $length = $_.Name.length
    $name = $_.Name.substring(0, $length-9) + "-$date.csv"
    $name2 = $_.Name.substring(0, $length-9) + "-$date2.csv"
    #$name
    Get-Content $_.FullName | Out-File -Encoding "UTF8" "$Pathe\$name"

    #cleanup file from 24 hours ago.
    
    if (Test-Path "$Pathe\$name2" -PathType leaf){
    $file = Get-ChildItem -Path "$Pathe\$name"
    $file2 = Get-ChildItem -Path "$Pathe\$name2"
       
    #System.IO is a namespace of the file class in .NET and GetLastWriteTime/SetLastWriteTime are methods of this class.
    if ([System.IO.File]::GetLastWriteTime($file2) -lt [System.IO.File]::GetLastWriteTime($file))
        {
            "$file2 LastWriteTime is less than $file"
            "Let's Delete $file2"
            Remove-Item -Path $file2
        }
    }
}

