﻿[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
cd "C:\Users\sumoadmin\Powershell"
#.\azcopy.exe --help

$Tenn = [System.Environment]::GetEnvironmentVariable('AZCOPY_TENANT_ID','machine')
$AppID = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_APPLICATION_ID','machine')
$ClientID = [System.Environment]::GetEnvironmentVariable('USER_MSI_ID','machine')
$uri = 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net&client_id='+$ClientID

# Make an API call to OAuth Token Endpoint to get the token. The endpoint 169.254.169.254 is only routable within azure and azure resources
$Response = Invoke-RestMethod -Uri $uri -Method GET -Headers @{Metadata="true"}

# Extract the Access token from the response
$KeyVaultToken = $Response.access_token

#Server side storage copy
$SourceStorageAccount = "dacblobbackup" # fill the source storage account
$SourceStorageKey = (Invoke-RestMethod -Uri https://dackeyvault.vault.azure.net/secrets/dacblobbackup-sas-token/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value
$DestStorageAccount = "adlstest01" # fill the destination storage account
$DestStorageKey = (Invoke-RestMethod -Uri https://dackeyvault.vault.azure.net/secrets/adlstest01-sas-token/?api-version=7.2 -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value

.\azcopy.exe login --identity --identity-client-id $ClientID

#$containers = @('raw-bih', 'raw-biu-faithinfines', 'raw-treasuryprocurement-paas', 'raw-dpc-piu', 'raw-dpie-paas', 'raw-archive/PHDB', 'raw-ctp', 'raw-hbc', 'raw-sira-analytics', 'raw-billcheck', 'raw-covid19/BlackDogInstitute', 'raw-fairtrading', 'raw-covid19/ANZ_Bank', 'raw-covid19/SNSWBCP', 'raw-covid19/SNSWNYERegidata', 'raw-covid19/TfNSW', 'raw-Tcorp', 'raw-archive/DeptofEducation', 'raw-archive/FACS', 'raw-archive/MinistoryofHealth', 'raw-archive/BeaureofCrimeStatisticsResearch', 'raw-archive >BirthsDeathsMarriages', 'raw-hsds', 'raw-brd-paas', 'raw-dpc-dsa', 'raw-covid19/BRD_Regulatory_Dashboard', 'raw-covid19/Covidsafe_businesscontact', 'raw-covid19/Covidsafeplan', 'raw-covid19/DineandDiscover', 'raw-archive/SNSWUnplannedleave', 'raw-archive >CancerInstituteNSW', 'raw-citaf', 'raw-covid19/Quantium', 'raw-covid19/SocialImpact_Dashboard/FACS', 'raw-covid19/SocialImpact_Dashboard/DCJ', 'raw-covid19/SocialImpact_Dashboard/Health', 'raw-covid19/NSWPF')
$containers = @('dac-hdfsbackup-container/temp', 'dac-azureconfigbackup-container', 'dac-mysqlbackup-container/policy')

foreach ($container in $containers) {
$source = "https://$SourceStorageAccount.blob.core.windows.net/$container$SourceStorageKey"
$destination = "https://$DestStorageAccount.blob.core.windows.net/$container$DestStorageKey"
                
#azcopy copy "https://[account].blob.core.windows.net/[container]/[path/to/blob]?[SAS]" "https://[account].blob.core.windows.net/[container]/[path/to/blob]" --recursive
.\azcopy.exe copy $source $destination --recursive
}




