﻿
# requires environmental variable set
# requires MSI enabled on VM
 
$ClientID = [System.Environment]::GetEnvironmentVariable('USER_MSI_ID','machine')

# Connect as Identity defined in ClientID
Connect-AzAccount -Identity -AccountId $clientId -Subscription "NSWDAC_PROD"




