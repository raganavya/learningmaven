﻿# https://www.rahulpnath.com/blog/accessing-azure-key-vault-from-azure-runbook/
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$ErrorActionPreference = 'stop'

$Tenn = [System.Environment]::GetEnvironmentVariable('AZCOPY_TENANT_ID','machine')
$AppID = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_APPLICATION_ID','machine')
$AADKey = [System.Environment]::GetEnvironmentVariable('AZCOPY_SPA_CLIENT_SECRET','machine')

$ssAADKey = ConvertTo-SecureString $AADKey -AsPlainText -Force
$psCredential = New-Object System.Management.Automation.PSCredential($AppID, $ssAADKey)
Connect-AzureRmAccount -ServicePrincipal -Credential $psCredential -TenantId $Tenn
#$myApp = Get-AzureADApplication -Filter "DisplayName eq '$($AppName)'"  -ErrorAction SilentlyContinue

$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'AUS Eastern Standard Time'); #Australia/Sydney
$startDate = $($now.Date.AddDays(-30))
$endDate = $($now.Date)
$datestring = $now.ToString("dd/MM/yyyy")
$datestring2 = $now.ToString("ddMMyyyy")

cd \temp
$output = ('\temp\DAC-ExpiredKeys '+ $datestring2 + '.xlsx')

#get all vault names
#PROD
$SubscriptionId3 = [System.Environment]::GetEnvironmentVariable('PROD_SUB','machine')
Set-AzureRmContext -SubscriptionId $SubscriptionId3
$vaults = Get-AzureRMKeyVault

# Params - VaultName, KeyVersions, SecretVersion, AlertBeforeDays
#$VaultName = 'DACKeyVault'
$IncludeAllKeyVersions = $false
$IncludeAllSecretVersions = $false
$AlertBeforeDays = 14

# Get Keys (flag to specify all versions)
   
# Convert keys common model of Object (Id, Name, Version,Expiry, Enabled)

Function New-KeyVaultObject
{
    param
    (
        [string]$Id,
        [string]$Name,
        [string]$Version,
        [System.Nullable[DateTime]]$Expires
    )

    $server = New-Object -TypeName PSObject
    $server | Add-Member -MemberType NoteProperty -Name Id -Value $Id
    $server | Add-Member -MemberType NoteProperty -Name Name -Value $Name
    $server | Add-Member -MemberType NoteProperty -Name Version -Value $Version
    $server | Add-Member -MemberType NoteProperty -Name Expires -Value $Expires
    
    return $server
}

Function New-ForbiddenObject
{
    param
    (
        [string]$Vault,
        [string]$Type
    )

    $server = New-Object -TypeName PSObject
    $server | Add-Member -MemberType NoteProperty -Name Vault -Value $Vault
    $server | Add-Member -MemberType NoteProperty -Name Type -Value $Type

    return $server
}

function Get-AzureKeyVaultObjectKeys
{
  param
  (
   [string]$VaultName,
   [bool]$IncludeAllVersions
  )

  $vaultObjects = [System.Collections.ArrayList]@()
  try{
  $allKeys = Get-AzureKeyVaultKey -VaultName $VaultName
  foreach ($key in $allKeys) {
    if($IncludeAllVersions){
     $allSecretVersion = Get-AzureKeyVaultKey -VaultName $VaultName -IncludeVersions -Name $key.Name
     foreach($key in $allSecretVersion){
         $vaultObject = New-KeyVaultObject -Id $key.Id -Name $key.Name -Version $key.Version -Expires $key.Expires
         $vaultObjects.Add($vaultObject)
     }
     
    } else {
      $vaultObject = New-KeyVaultObject -Id $key.Id -Name $key.Name -Version $key.Version -Expires $key.Expires
      $vaultObjects.Add($vaultObject)
    }
  }
  
  return $vaultObjects
  }
  catch{
    #Write-Host "Cannot get key "
    $forbiddenObject = New-ForbiddenObject -Vault $VaultName -Type "Key"
    $forbiddenObjects.Add($forbiddenObject)
    }
}

function Get-AzureKeyVaultObjectSecrets
{
  param
  (
   [string]$VaultName,
   [bool]$IncludeAllVersions
  )

  $vaultObjects = [System.Collections.ArrayList]@()
  try{
  $allSecrets = Get-AzureKeyVaultSecret -VaultName $VaultName
  foreach ($secret in $allSecrets) {
    if($IncludeAllVersions){
     $allSecretVersion = Get-AzureKeyVaultSecret -VaultName $VaultName -IncludeVersions -Name $secret.Name
     foreach($secret in $allSecretVersion){
         $vaultObject = New-KeyVaultObject -Id $secret.Id -Name $secret.Name -Version $secret.Version -Expires $secret.Expires
         $vaultObjects.Add($vaultObject)
     }
     
    } else {
      $vaultObject = New-KeyVaultObject -Id $secret.Id -Name $secret.Name -Version $secret.Version -Expires $secret.Expires
      $vaultObjects.Add($vaultObject)
    }
  }
  
  return $vaultObjects
    }
  catch{
    #Write-Host "Cannot get secret "
    $forbiddenObject = New-ForbiddenObject -Vault $VaultName -Type "Secret"
    $forbiddenObjects.Add($forbiddenObject)
    }
}

$allKeyVaultObjects = [System.Collections.ArrayList]@()
$expiredKeyVaultObjects = [System.Collections.ArrayList]@()
$forbiddenObjects = [System.Collections.ArrayList]@()

foreach($vault in $vaults){

$vault.VaultName


$tempkey = Get-AzureKeyVaultObjectKeys -VaultName $vault.VaultName -IncludeAllVersions $IncludeAllKeyVersions
if($tempkey.length -gt 1)
    {
        $allKeyVaultObjects.AddRange($tempkey)
    } 

$tempsecret = Get-AzureKeyVaultObjectSecrets -VaultName $vault.VaultName -IncludeAllVersions $IncludeAllSecretVersions
if($tempsecret.length -gt 1)
    {
        $allKeyVaultObjects.AddRange($tempsecret)
    }

#$allKeyVaultObjects.AddRange((Get-AzureKeyVaultObjectKeys -VaultName $vault.VaultName -IncludeAllVersions $IncludeAllKeyVersions))
#$allKeyVaultObjects.AddRange((Get-AzureKeyVaultObjectSecrets -VaultName $vault.VaultName -IncludeAllVersions $IncludeAllSecretVersions))

}

# Get expired Objects
$today = (Get-Date).Date  #(Get-Date -Year 2022 -Month 1 -Day 18)
foreach($vaultObject in $allKeyVaultObjects){
if($vaultObject.Expires -and $vaultObject.Expires.AddDays(-$AlertBeforeDays).Date -lt $today)
{
  # add to expiry list
  $expiredKeyVaultObjects.Add($vaultObject) | Out-Null
  Write-Output "Expiring" $vaultObject.Id
}
}


if($forbiddenObjects){
      Write-Output "FORBIDDEN!" $forbiddenObjects
      $forbiddenObjectshtml = $forbiddenObjects | ConvertTo-Html -Fragment -As List
}


#SEND EMAIL With expired key Attachment
$emailSmtpServer = "smtp.sendgrid.net"
$emailSmtpServerPort = "25"
$emailSmtpUser = "apikey"
$emailSmtpPass = [System.Environment]::GetEnvironmentVariable('SMTP_TOKEN','machine')
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "DAC Support <dacsupport@customerservice.nsw.gov.au>"
$emailMessage.To.Add( "<Damien.Smith@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Manan.Tyagi@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Indu.Neelakandan@customerservice.nsw.gov.au>" )
$emailMessage.To.Add( "<Jaspreet.Singh@customerservice.nsw.gov.au>")
$emailMessage.To.Add( "<Preeti.Preeti@customerservice.nsw.gov.au>")
$emailMessage.Subject = ("DAC PROD Key Expiry " + $datestring)
$emailMessage.IsBodyHtml = $true


if ($expiredKeyVaultObjects -or $forbiddenObjects)
{
$expiredKeyVaultObjects| Export-Excel -path $output -WorksheetName "DAC-Expiring-Keys"
$emailMessage.Body = 
@"
<p> </p>
<p>Please find attached DAC PROD Azure Vault Keys/Secrets that will expire within 14 days.</p>
<p> - If there is no attachment then NO NON-PROD DAC Azure Vaults will expire within 14 days </p>
<p>The following Vaults did not allow dac-prod-runas-service-account to read </p>
$forbiddenObjectshtml
<p> - Please grant dac-prod-runas-service-account read on the Vault/Type noted </p>
<p> - Please also check if network is open </p>
<p> - If blank then NO PROD DAC Azure Vaults have denied dac-prod-runas-service-account to read </p>
<p> </p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

if($expiredKeyVaultObjects){
    $attachment1 = new-object Net.Mail.Attachment($output)
    $emailMessage.Attachments.Add($attachment1)
    }
}
else
{
$emailMessage.Body = 
@"
<p> </p>
<p><strong>Good News! </strong> </p> 
<p> </p>
<p>Please be advised that: </p> 
<p> </p> 
<p> - NO PROD DAC Azure Vault Keys/Secrets will expire within 14 days.</p>
<p> - NO PROD DAC Azure Vaults denied dac-prod-runas-service-account to read.</p>
<p>Thank you,</p>
<p>Azure Cloud Mail Service. </p>
<p> </p>
<p>Please do not reply to this email.</p>
"@

}
$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );

$SMTPClient.Send($emailMessage)

