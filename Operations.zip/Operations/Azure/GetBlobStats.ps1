﻿[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
# CONSTANTS
$filesystemName = "raw-ctp"   #Container name
$outputFileNamePrefix = 'C:\Users\damien.smith\Desktop\Powershell\OutputFolder\raw-ctp'
$MaxReturn = 5000 #no need to change this

#### MAIN ####

Set-AzContext -SubscriptionId 'NSWDAC_PROD'
$storageAccount = Get-AzStorageAccount -ResourceGroupName "dac-datalake-rg" -AccountName "dacdatalake01"
$ctx = $storageAccount.Context

$allItems = @()
$Total = 0
$Token = $Null
do
{
     $items = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $FileSystemName -Recurse -MaxCount $MaxReturn -ContinuationToken $Token
     #$Name = $items.Path
     #$Total += $items.Count
     #$dir = $items.Length
     if($items.Length -le 0) { Break;}
     $Token = $items[$items.Count -1].ContinuationToken;
     #Echo "Folder or path $Name has size equal to $dir"
     $allItems += $items
 }
While ($Token -ne $Null) 


$allFiles = $allItems | Where-Object -FilterScript { -Not $_.IsDirectory }
$allDirs = $allItems | Where-Object -FilterScript { $_.IsDirectory }

$rowObjects = $allFiles | select Path, IsDirectory, Length, LastModified, Owner, Group
$rowObjects | Export-Csv -Path "$($outputFileNamePrefix)_files.csv" -NoTypeInformation

$rowObjects = $allDirs | select Path, IsDirectory, Length, LastModified, Owner, Group
$rowObjects  | Export-Csv -Path "$($outputFileNamePrefix)_dirs.csv" -NoTypeInformation

$rowObjects = $allItems | select Path, IsDirectory, Length, LastModified, Owner, Group
$rowObjects | Export-Csv -Path "$($outputFileNamePrefix).csv" -NoTypeInformation
