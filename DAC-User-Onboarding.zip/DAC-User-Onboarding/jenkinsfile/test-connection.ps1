#! /usr/bin/pwsh
param(
        [Parameter(Mandatory=$true)]$computer,
        [Parameter(Mandatory=$true)]$username,
        [Parameter(Mandatory=$true)]$password
)
$secureString = ConvertTo-SecureString $password -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential -ArgumentList ($username,$secureString)
$testSession = New-PSSession -Computer $computer -credential $credential -Authentication Negotiate
if(-not($testSession))
{
    Write-Warning "$computer inaccessible!"
    exit
}
else
{
    Write-Host "Great! $computer is accessible!"
    Remove-PSSession $testSession
}