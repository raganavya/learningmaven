#! /usr/bin/pwsh
param(
        [Parameter(Mandatory=$true)]$computer,
        [Parameter(Mandatory=$true)]$username,
        [Parameter(Mandatory=$true)]$password,
        [Parameter(Mandatory=$true)]$copyFolder
)

$secureString = ConvertTo-SecureString $password -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential -ArgumentList ($username,$secureString)


function copyArtifact($computer,$credential,$copyFolder){ 
    $session = New-PSSession -ComputerName $computer -Credential $credential -Authentication Negotiate
    Copy-Item $copyFolder -Destination "C:\Temp\" -ToSession $session -Recurse -force
}

copyArtifact -computer $computer -credential $credential -copyFolder $copyFolder