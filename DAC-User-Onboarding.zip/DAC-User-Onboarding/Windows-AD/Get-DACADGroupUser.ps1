<#
.SYNOPSIS
  Get the AD Group Members in Active Directory
.DESCRIPTION
  This script exports the AD Group users from Active Directory
.PARAMETER <Parameter_Name>
  None
.INPUTS
  Enter AD Group Name
.OUTPUTS
  The script will export the output in a csv file.
.NOTES
  Version:        1.0
  Author:         Jaspreet
  Creation Date:  27/10/2020
  Purpose/Change: Initial script development
  
.EXAMPLE

Get-ADGroupUser -groupname "dac-qlik" -path "C:\Temp"
  
#>

#region Function Get-ADGroupUser
function Get-DACADGroupUser {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]$groupname, # Enter the group name of the user
        [Parameter(Mandatory=$true)]$path # Enter the Path of the csv file
    )

# Get the AD group member properties from the security group
Get-ADGroupMember -Identity $groupname | Get-ADUser -Properties emailaddress, title, Department, Name, GivenName, description, Enabled |`
Select-Object userprincipalname, givenname, surname, emailaddress, description, department, Enabled  |
#Loop through the list of members
    ForEach-Object {
            new-object psobject -Property @{
                                             login = $_.userprincipalname #sAMAccountName
                                             firstName  = $_.givenname
                                             lastName   = $_.surname
                                             email      = $_.emailaddress
                                            #Company    = $_.company
                                             department = $_.department
                                             Description = $_.description
                                             Enabled    = $_.enabled                                                                                          
                                             }
           } | Select-Object login, firstName, lastName, email,department, Description, Enabled |
           #Output the report to CSV
               Export-Csv $path -NoTypeInformation -Append
                      }