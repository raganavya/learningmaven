<#
.SYNOPSIS
  Add the Bulk users from csv in Active Directory Group
.DESCRIPTION
  This script add the bulk users in the Active Directory
.PARAMETER <Parameter_Name>
  None
.INPUTS
  Enter the csv path
.OUTPUTS
  None
.NOTES
  None
  
.EXAMPLE
 
#>

#region Function Add-ADGroupUser

# Import Active Directory module for running AD cmdlets

Import-Module activedirectory

#Store the data from ADUsers.csv in the $ADUsers variable
$Path = <Enter the csv Path>
$ADUsers = Import-csv -Path $Path
$domain = "@dac.local"
#Loop through each row containing user details in the CSV file

foreach ($User in $ADUsers)
{
#Read user data from each field in each row and assign the data to a variable as below
$Username = $User.username
$Password = $User.password
$Firstname = $User.firstname
$Lastname = $User.lastname
$OU = $User.ou
$email = $User.email
$city = $User.city
$jobtitle = $User.jobtitle
$department = $User.department
$Password = $User.Password

#Check to see if the user already exists in the AD

if (Get-ADUser -Filter {SamAccountName -eq $Username})
{
#If the user does exist, give a warning
Write-Warning "A user account with username $Username already exists in Active Directory."
}
else
{
#User does not exist then proceed to create the new user account
#Account will be created in the OU provided by the $OU variable read from the CSV file
New-ADUser `
-SamAccountName $Username `
-UserPrincipalName "$Username$domain" `
-Name "$Firstname $Lastname" `
-GivenName $Firstname `
-Surname $Lastname `
-Enabled $True `
-DisplayName "$Lastname, $Firstname" `
-Path $OU `
-City $city `
-EmailAddress $email `
-Title $jobtitle `
-Department $department `
-AccountPassword (convertto-securestring $Password -AsPlainText -Force)
-ChangePasswordAtLogon $True

}
}