<#
.SYNOPSIS
  Add the AD user in Active Directory Group
.DESCRIPTION
  This script add the user in the AD Group in Active Directory
.PARAMETER <Parameter_Name>
  None
.INPUTS
  Enter AD Group Name
.OUTPUTS
  None
.NOTES
  Version:        1.0
  Author:         Jaspreet
  Creation Date:  30/04/2021
  Purpose/Change: Initial script development
  
.EXAMPLE

Add-DacAdGroupUser -groupname "dac-qlik" -user "Jaspreet Singh"
  
#>

#region Function Add-ADGroupUser
function Add-DacAdGroupUser 
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]$groupname, # Enter the group name of the user
        [Parameter(Mandatory=$true)]$user # Enter the name of the user
    )
    try{
       Add-ADGroupMember -Identity $groupname -Members $user
    }
    Catch{
       write-host "Unable to add $user to the AD Group named $groupname!"
       return 1
    }
    
    # Verify if the user has been added to the AD Group
    Write-Host "The $user has been added to the AD Group named $groupname"
}
