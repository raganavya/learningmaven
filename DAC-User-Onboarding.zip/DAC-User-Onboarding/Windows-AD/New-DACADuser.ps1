<#
.SYNOPSIS
  Create the user in Active Directory
.DESCRIPTION
  This script creates the user in Active Directory
.PARAMETER <Parameter_Name>
  None
.INPUTS
  Enter FirstName and LastName
.OUTPUTS
  The script will display the output.
.NOTES
  Version:        1.1
  Author:         Jaspreet
  Creation Date:  30/04/2021
  Purpose/Change: Initial script development
  Reference: https://thesysadminchannel.com/script-create-user-accounts-in-powershell/
  Reference: https://jdhitsolutions.com/blog/powershell/6348/building-more-powershell-functions/
  
.EXAMPLE

CreateADUser -firstname Joe -lastname Higgins -email "joe.higgins@customerservice.nsw.gov.au" -description "IT" -username "joe.higgins"
  
#>

#region Function New-DACADuser

Function New-DACADuser

{

[CmdLetBinding()]

param(
 [Parameter(Mandatory=$true)]$firstname, # Enter the first name of the user
 [Parameter(Mandatory=$true)]$lastname, # Enter the last name of the user
 [Parameter(Mandatory=$true)]$email, # Enter the email of the user
 [Parameter(Mandatory=$true)]$description, # Enter the Description of the user
 [Parameter(Mandatory=$true)]$username, # Enter the username of the user
 [Parameter(Mandatory=$false)]$ou # Enter the ou of the user
 
 )

 $Password = "Dac2021!" | ConvertTo-SecureString -AsPlainText -Force
 $ou = "OU=Users,OU=Prod,OU=DAC,DC=dac,DC=local"
 $domain = "@dac.local"

# Check if the user already exists in AD

if (Get-ADUser -Filter {SamaccountName -eq $username})
    {

    # If user does exist, output a warning message
     write-host "$username already exists in Active Directory"
    }
else
    {

    #If a user does not exist then create a new user account
Try{
 
New-ADUser  `
          -Name “$firstname $lastname” `
          -AccountPassword $Password `
          -SamAccountName $username `
          -DisplayName "$firstname $lastname" `
          -EmailAddress "$email" `
          -Description "$description" `
          -Path "$ou" `
          -ChangePasswordAtLogon $False `
          -Enabled $True `
          -GivenName "$firstname" `
          -Surname "$lastname" `
          -UserPrincipalName "$username$domain" `
          -PasswordNeverExpires $True `
          -PassThru `
          -ErrorAction Stop

          Write-Host "User $username created successfully" 
}

Catch{
        Write-Host "There was a problem creating User $username. The account was not created!" 
        return 1
                  
}

}
}

#endregion
                 