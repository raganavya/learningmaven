<#
.SYNOPSIS
ExportUsersFromADGroup.ps1 - Exports the user from the Security Group.

.DESCRIPTION 
This script export the users from the security groups in a csv format.

.OUTPUTS
The report is output to CSV file.

.EXAMPLE
.\ExportUsersFromADGroup.ps1

.EXAMPLE
.\ExportUsersFromADGroup.ps1 -Verbose

.LINK
https://stackoverflow.com/questions/52040689/extracting-ad-records-attributes-from-a-group-but-need-managers-email-address-a
http://woshub.com/get-aduser-getting-active-directory-users-data-via-powershell/

.NOTES
Script provided by community members and re-factored to work according to our environment

Version history:
V1.00, 02/10/2019 - Initial version

#>

#...................................
# Variables
#...................................

$path = "c:\Temp\script-$((get-date).tostring('dd-MM-yyyy')).csv"
$SecurityGroup = 'dac-qlik-ctp'

#...................................
# Script
#...................................

# Get the AD group member properties from the security group
get-adgroupmember $SecurityGroup | Get-ADUser -Properties emailaddress, title, Department, Name, GivenName, description | Select-Object userprincipalname, givenname, surname, emailaddress, description, department |
#Loop through the list of members
    ForEach-Object {
            new-object psobject -Property @{
                                             login = $_.userprincipalname #sAMAccountName
                                             firstName  = $_.givenname
                                             lastName   = $_.surname
                                             email      = $_.emailaddress
                                            #Company    = $_.company
                                             department = $_.department
                                             Description = $_.description
                                             Status     = $_.Enabled -eq "$true"
                                             
                                             }
           } | Select-Object login, firstName, lastName, email,department, Description, Status |
           #Output the report to CSV
               Export-Csv $path -NoTypeInformation


