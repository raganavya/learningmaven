This repo has powershell command which can be used at LDAP. 

This repo has below scripts
(1) Log File with Powershell
(2) Add User Import
(3) Add AD Group
(4) Ger AD UserProperties
(5) Get User List 
(6) update User Principal name 
