﻿##############################################################################################
# This script adds existing AD members to a specific group 
##############################################################################################


$StartTime   = Get-Date -UFormat "%Y%m%d_%H%M"
$LogFileName = "C:\Work\ADUserGrp.log"        

$Users = Import-Csv -Path "C:\Work\ADUserGroupAdd.csv"            
foreach ($User in $Users)            
{            
    $UserCheck = $null
    $Displayname = $User.'Firstname' + " " + $User.'Lastname'            
    $UserFirstname = $User.'Firstname'            
    $UserLastname = $User.'Lastname'            
    $OU = $User.'OU'            
    $SAM = $User.'SAM'            
    $UPN = $User.'Firstname' + "." + $User.'Lastname' + "@" + $User.'Maildomain'     
    $EMAIL = $User.'Mail'      
    $Description = $User.'Description'            
    $Password = $User.'Password'   
    $QLikgroupName='dac-qlik'     
    $GroupNamesString = $User.'GroupNamesString'
    
 
   Write-Output "AD User Group Addition started  at  $StartTime  " | Out-File -FilePath $LogFileName -Append

    # check if username exists already in AD

    $UserCheck = Get-ADUser -Filter {sAMAccountName -eq $SAM}
    
    # Check search result to see if user exists to add to AD group
    If ($usercheck -ne $null) 
    {

            # $group = "Domain Admins"
            $members = Get-ADGroupMember -Identity $QLikgroupName -Recursive | Select -ExpandProperty SamAccountName

            If ($members -contains $SAM) 
            {
                # Write-Host "$user exists in the group"
                Write-Output "$SAM exists in  group $QLikgroupName " | Out-file $LogFileName -append
            } 
            Else 
            {
                Add-ADGroupMember -Identity $QLikgroupName -Members "$SAM"
          
                Write-Output "User - $SAM  added to $QLikgroupName " | Out-file $LogFileName -append

            }

            
 
      

    }
    Else { 
          # Write-Host "User: "$SAM "already exists!"`n`r
           Write-Output "User: $SAM does not exist!" | Out-file $LogFileName -append
           
         }

}

$EndTime = Get-Date -UFormat "%Y%m%d_%H%M%S"
 
Write-Output "AD User Group Addition started  at  $StartTime  and ended at $EndTime. " | Out-File -FilePath $LogFileName -Append


