﻿# Export Application Logs
# Author: Damien Smith
# Date: 05/04/2019
#
# Set your log types
# Set your search

$logTypes = 'Application'     # add the types of logs you wish to see [options are: 'Application', 'Security', 'Setup', 'System', 'Forwarded Events']
$likeSearch = '*Qlik*'        # type the application you wish to group by 


Set-Variable -Name ExportFolder -Value "C:\TEST\"
$now=get-date

$ExportFile=$ExportFolder + "Qlik Log " + $now.ToString("yyyy-MM-dd---hh-mm-ss") + ".log"  


get-eventlog -log $logTypes | Where-Object {$_.Source -Like $likeSearch} > $ExportFile 




# get-eventlog -log Application | findstr -i Qlik

# get-eventlog -log Application | Select-String -Pattern "Qlik"



# Best Option:
get-eventlog -log Application | Where-Object {$_.Source -Like '*Qlik*'}

# Best Option with output to file:
Set-Variable -Name ExportFolder -Value "C:\TEST\"

$now=get-date
$startdate=$now.adddays(-$EventAgeDays)
$ExportFile=$ExportFolder + "Qlik Log " + $now.ToString("yyyy-MM-dd---hh-mm-ss") + ".log"  


get-eventlog -log Application | Where-Object {$_.Source -Like '*Qlik*'} > $ExportFile 
