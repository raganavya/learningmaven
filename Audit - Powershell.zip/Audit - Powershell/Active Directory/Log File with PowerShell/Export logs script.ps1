﻿#
#  This script exports consolidated and filtered event logs to CSV
#  This script can accept an array of LogNames and Event types
#

$likeSearch = '*Qlik*'                                               # The application you wish to group by 
Set-Variable -Name LogNames -Value @("Application", "System")        # Checking app and system logs [options are: 'Application', 'Security', 'Setup', 'System', 'Forwarded Events']
Set-Variable -Name EventTypes -Value @("Error", "Warning")           # Loading only Errors and Warnings [options are: Error, Information, FailureAudit, SuccessAudit, Warning]
Set-Variable -Name ExportFolder -Value "C:\TEST\"                    # Set the location where you want to save .log files


$el_c = @()   #event log consolidation variable
$now=get-date
$ExportFile=$ExportFolder + "Event Log" + $now.ToString("yyyy-MM-dd---hh-mm-ss") + ".log"      # we cannot use delimiters like ": or ,"

  foreach($log in $LogNames)
  {
    $el = get-eventlog -log $log -EntryType $EventTypes
    $el_c += $el  #consolidating
  }


$el_sorted = $el_c | Sort-Object TimeGenerated                         #sort by time
$el_sorted| Where-Object {$_.Source -Like $likeSearch} > $ExportFile   #EXPORT
