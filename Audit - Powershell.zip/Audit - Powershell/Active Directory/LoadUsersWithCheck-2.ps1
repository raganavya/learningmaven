﻿##############################################################################################
# Create AD users in bulk and add to AD group
# AD groups are separated by , in the source csv file
##############################################################################################

$StartTime   = Get-Date -UFormat "%Y%m%d_%H%M"
$LogFileName = "C:\Work\ADUserImport.log"        

$Users = Import-Csv -Path "ADUserImport.csv            
foreach ($User in $Users)            
{            
    $UserCheck = $null
    $Displayname = $User.'Firstname' + " " + $User.'Lastname'            
    $UserFirstname = $User.'Firstname'            
    $UserLastname = $User.'Lastname'            
    $OU = $User.'OU'            
    $SAM = $User.'SAM'            
    $UPN = $User.'Firstname' + "." + $User.'Lastname' + "@" + $User.'Maildomain'     
    $lowerUPN = $UPN.ToLower()   
    $EMAIL = $User.'Mail'      
    $Description = $User.'Description'            
    $Password = $User.'Password'   
    # $QLikgroupName='dac-qlik'     
    $GroupNamesString = $User.'GroupNamesString'
    
 
   Write-Output "AD User creation started  at  $StartTime  " | Out-File -FilePath $LogFileName -Append

    # check if username exists already in AD

    $UserCheck = Get-ADUser -Filter {sAMAccountName -eq $SAM}
    
    # Check search result to see if it's Null and then create the user

    If ($usercheck -eq $null) 
    {

       # Write-Host "User Check Completed - "  $SAM  " doesn't exist" 
 
        New-ADUser -Name "$Displayname" -DisplayName "$Displayname" -SamAccountName $SAM -UserPrincipalName $lowerUPN -GivenName "$UserFirstname" -Surname "$UserLastname" -EmailAddress "$EMAIL" -Description "$Description" -AccountPassword (ConvertTo-SecureString $Password -AsPlainText -Force) -Enabled $true -Path "$OU" -ChangePasswordAtLogon $false –PasswordNeverExpires $true -server dac.local            
        
        Write-Output "User - $SAM  Created" | Out-file $LogFileName -append
        
        foreach  ($GroupName in $GroupNamesString.Split(","))
         {
           
           Add-ADGroupMember -Identity $GroupName -Members "$SAM"
          
           Write-Output "User - $SAM  added to $GroupName " | Out-file $LogFileName -append
         }
        

         # Write-Host "User - "  $SAM  " Created"
       
      

    }

    # If it's not null, print out to screen

    Else { 
          # Write-Host "User: "$SAM "already exists!"`n`r
           Write-Output "User: $SAM already exists!" | Out-file $LogFileName -append
           
         }

}

$EndTime = Get-Date -UFormat "%Y%m%d_%H%M%S"
 
Write-Output "AD User creation started  at  $StartTime  and ended at $EndTime. " | Out-File -FilePath $LogFileName -Append