﻿Get-ADUser -Filter '*' -Properties *  | 
Where {$_.GivenName -ne $Null -AND $_.Surname -ne $Null -AND $_.Name -ne $Null} | % {
New-Object PSObject -Property @{
FullName = $_.Name
Username = $_.DisplayName
Description=$_.description
Enabled=$_.enabled
CreatedDate=$_.WhenCreated
LastLogonDate=$_.LastLogonDate
}
} | Select FullName,Description, Enabled,CreatedDate,LastLogonDate|
Export-CSV  C:\Work\UserList.csv