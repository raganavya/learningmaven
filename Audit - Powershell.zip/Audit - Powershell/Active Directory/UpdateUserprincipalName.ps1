﻿
$StartTime   = Get-Date -UFormat "%Y%m%d_%H%M"
$LogFileName = "C:\Work\UpdateUserPrincipalName.log"        

$Users = Import-Csv -Path "C:\Work\UpdateUserPrincipalName.csv"            
foreach ($User in $Users)            
{            
    $UserCheck = $null
    $Displayname = $User.'Firstname' + " " + $User.'Lastname'            
    $UserFirstname = $User.'Firstname'            
    $UserLastname = $User.'Lastname'            
    $OU = $User.'OU'            
    $SAM = $User.'SAM'            
    $UPN = $User.'Firstname' + "." + $User.'Lastname' + "@" + $User.'Maildomain'   
    $lowerUPN = $UPN.ToLower()   
    $EMAIL = $User.'Mail'      
    $Description = $User.'Description'            
    $Password = $User.'Password'   
    # $QLikgroupName='dac-qlik'     
    $GroupNamesString = $User.'GroupNamesString'
    
 
   Write-Output "AD User creation started  at  $StartTime  " | Out-File -FilePath $LogFileName -Append

    # check if username exists already in AD

    $UserCheck = Get-ADUser -Filter {sAMAccountName -eq $SAM}
    
    # Check search result to see if it's Null and then create the user

          
           Set-ADUser -Identity $SAM -UserPrincipalName  $lowerUPN
          
           Write-Output "User - $SAM  modified to $lowerUPN" | Out-file $LogFileName -append
 
      

    }



$EndTime = Get-Date -UFormat "%Y%m%d_%H%M%S"
 
Write-Output "AD User update started  at  $StartTime  and ended at $EndTime. " | Out-File -FilePath $LogFileName -Append