﻿
Connect-AzureAD

cd C:\Users\AzureUser
$output = ('C:\Users\AzureUser\azgroupdetails.xlsx')
if (Test-Path -Path $output) {rm -Force $output}


#Get group details
$gg = Get-AzureADGroup -All $true
$arr4 = @()
    ForEach ($g in $gg){
        $a = Get-AzureADGroup -ObjectId $g.ObjectId  
        $b = Get-AzureADGroupMember -ObjectId $g.ObjectId -All $true 
        ForEach ($c in $b){
        $arr4 += [pscustomobject]@{
            GroupName =  $a.DisplayName
            GroupID = $a.ObjectId
            UserID = $c.ObjectId
            Username = $c.UserPrincipalName
        }
        }
}
$arr4 | Export-Excel -path $output -WorksheetName "Groupdetails"
