﻿
$SubscriptionId3 = '7e3a186c-57f5-4b5c-b1d5-02f5ee54da94'
Set-AzContext -SubscriptionId $SubscriptionId3
$storageAccount = Get-AzStorageAccount -ResourceGroupName "npdac-datalake-rg" -AccountName "npdacdatalake01"
$ctx = $storageAccount.Context
$filesystemName = "user"
#$dir = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $filesystemName -Recurse -FetchProperty

$MaxReturn = 10000

$Total = 0
$Token = $Null
do
 {
     $items = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $FileSystemName -Recurse -MaxCount $MaxReturn  -ContinuationToken $Token
     $Name = $items.Path
     #$Total += $items.Count
     $dir = $items.Length
     #$dir
     if($items.Length -le 0) { Break;}
     $Token = $items[$items.Count -1].ContinuationToken;
     Echo "Folder or path $Name has size equal to $dir "
     " "
 }
 While ($Token -ne $Null)
#Echo "Folder or path $Name has size equal to $dir"