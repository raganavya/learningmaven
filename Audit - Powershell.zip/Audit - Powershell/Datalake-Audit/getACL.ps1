﻿
Connect-AzAccount

cd C:\Users\AzureUser
$output = ('C:\Users\AzureUser\DACACL1.xlsx')
if (Test-Path -Path $output) {rm -Force $output}


$SubscriptionId3 = '7e3a186c-57f5-4b5c-b1d5-02f5ee54da94'
Set-AzContext -SubscriptionId $SubscriptionId3
$storageAccount = Get-AzStorageAccount -ResourceGroupName "npdac-datalake-rg" -AccountName "npdacdatalake01"
$ctx = $storageAccount.Context
$filesystemName = "projects"
$dir = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $filesystemName -Recurse -FetchProperty
$arr = @()
foreach ($f in $dir){
    $n = @($f.ACL.EntityId).Count
    for ($i=0; $i -lt $n; $i++) {
        $uid = @($f.ACL.EntityId)[$i]
        $grp = @($f.ACL.AccessControlType)[$i]
        $user = ""
        if ($uid -And $grp -eq "User") {
            $user = Get-AzADUser -ObjectId $uid
        } 
        elseif ($uid -And $grp -eq "Group") {
            $user = Get-AzADGroup -ObjectId $uid
        }
        elseif ($uid -And $grp -eq "Other") {
            $user = Get-AzureADObjectByObjectId -ObjectId $uid
        }

        else {
            $user = "no username found"
        }
    $arr += [pscustomobject]@{
        Name = $f.Name
        ID = @($f.ACL.EntityId)[$i]
        Username = $user.DisplayName
        RoleType = @($f.ACL.AccessControlType)[$i]
        Accesslevel = @($f.ACL.Permissions)[$i]
    }
    }
}
#For Raw Container
$filesystemName = "projects-covid19"
$dir1 = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $filesystemName -Recurse -FetchProperty
$arr1 = @()
foreach ($f1 in $dir1){
    $n = @($f1.ACL.EntityId).Count
    for ($i=0; $i -lt $n; $i++) {
        $uid1 = @($f1.ACL.EntityId)[$i]
        $grp1 = @($f1.ACL.AccessControlType)[$i]
        $user = ""
        if ($uid1 -And $grp1 -eq "User") {
            $user = Get-AzADUser -ObjectId $uid1
        } 
        elseif ($uid1 -And $grp1 -eq "Group") {
            $user = Get-AzADGroup -ObjectId $uid1
        }

        else {
            $user = "no username found"
        }
    $arr1 += [pscustomobject]@{
        Name = $f1.Name
        ID = @($f1.ACL.EntityId)[$i]
        Username = $user.DisplayName
        RoleType = @($f1.ACL.AccessControlType)[$i]
        Accesslevel = @($f1.ACL.Permissions)[$i]
    }
    }
}
#For Staging Container
$filesystemName = "raw"
$dir2 = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $filesystemName -Recurse -FetchProperty
$arr2 = @()
foreach ($f1 in $dir2){
    $n = @($f1.ACL.EntityId).Count
    for ($i=0; $i -lt $n; $i++) {
        $uid1 = @($f1.ACL.EntityId)[$i]
        $grp1 = @($f1.ACL.AccessControlType)[$i]
        $user = ""
        if ($uid1 -And $grp1 -eq "User") {
            $user = Get-AzADUser -ObjectId $uid1
        } 
        elseif ($uid1 -And $grp1 -eq "Group") {
            $user = Get-AzADGroup -ObjectId $uid1
        }

        else {
            $user = "no username found"
        }
    $arr2 += [pscustomobject]@{
        Name = $f1.Name
        ID = @($f1.ACL.EntityId)[$i]
        Username = $user.DisplayName
        RoleType = @($f1.ACL.AccessControlType)[$i]
        Accesslevel = @($f1.ACL.Permissions)[$i]
    }
    }
}
#For Staging Container
$filesystemName = "raw-archive"
$dir3 = Get-AzDataLakeGen2ChildItem -Context $ctx -FileSystem $filesystemName -Recurse -FetchProperty
$arr3 = @()
foreach ($f1 in $dir2){
    $n = @($f1.ACL.EntityId).Count
    for ($i=0; $i -lt $n; $i++) {
        $uid1 = @($f1.ACL.EntityId)[$i]
        $grp1 = @($f1.ACL.AccessControlType)[$i]
        $user = ""
        if ($uid1 -And $grp1 -eq "User") {
            $user = Get-AzADUser -ObjectId $uid1
        } 
        elseif ($uid1 -And $grp1 -eq "Group") {
            $user = Get-AzADGroup -ObjectId $uid1
        }

        else {
            $user = "no username found"
        }
    $arr3 += [pscustomobject]@{
        Name = $f1.Name
        ID = @($f1.ACL.EntityId)[$i]
        Username = $user.DisplayName
        RoleType = @($f1.ACL.AccessControlType)[$i]
        Accesslevel = @($f1.ACL.Permissions)[$i]
    }
    }
}

$arr | Export-Excel -path $output -WorksheetName "Projects"
$arr1 | Export-Excel -path $output -WorksheetName "projects-covid19"
$arr2 | Export-Excel -path $output -WorksheetName "raw"
$arr3 | Export-Excel -path $output -WorksheetName "raw-archive"

