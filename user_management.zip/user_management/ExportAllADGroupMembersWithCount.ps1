﻿$Path = 'C:\Work\Jaspreet_Scripts\GroupMemberCount.csv'

Get-ADGroup -Properties Name, Members -Filter '*' |
    ForEach-Object {
        [PSCustomObject]@{
            Name = $_.Name
            MemberCount = $_.Members.Count
        }
    } | Export-Csv -Path $Path