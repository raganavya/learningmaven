﻿<#
.SYNOPSIS
  Create the user in Active Directory
.DESCRIPTION
  This script creates the user in Active Directory
.PARAMETER <Parameter_Name>
  None
.INPUTS
  Enter FirstName and LastName
.OUTPUTS
  The script will display the output.
.NOTES
  Version:        1.0
  Author:         Jaspreet
  Creation Date:  26/10/2020
  Purpose/Change: Initial script development
  Reference: https://thesysadminchannel.com/script-create-user-accounts-in-powershell/
  Reference: https://jdhitsolutions.com/blog/powershell/6348/building-more-powershell-functions/
  
.EXAMPLE

CreateADUser -firstname Joe -lastname Higgins -email "joe.higgins@customerservice.nsw.gov.au" -description "IT" -username "joe.higgins"
  
#>

#region Function New-DACADuser

Function New-DACADuser

{

[CmdLetBinding()]

param(
 [Parameter(Mandatory=$true)]$firstname, # Enter the first name of the user
 [Parameter(Mandatory=$true)]$lastname, # Enter the last name of the user
 [Parameter(Mandatory=$true)]$email, # Enter the email of the user
 [Parameter(Mandatory=$true)]$description, # Enter the Description of the user
 [Parameter(Mandatory=$true)]$username # Enter the Description of the user

 )

# Do not create user if it does exist

if (Get-aduser $username)
    {
     write-host "$username already exists"
    }
else
    {
 
# Select the OU for the user
$ou=Get-ADOrganizationalUnit -Filter * | Select-Object -Property DistinguishedName| Out-GridView -PassThru -Title "Choose an OU to place the user" | Select-Object -ExpandProperty DistinguishedName 

# Select the AD Group for the user
$group= Get-ADgroup -Filter * | Select-Object -Property Name| Out-GridView -PassThru -Title "Select the Group you want to add user, if none hit cancel" | Select-Object -ExpandProperty Name
 
#Enter your new user temporary defult password between the quotes.
$Password     = Read-Host -assecurestring "Please enter your password"

New-ADUser  `
          -Name “$firstname $lastname” `
          -AccountPassword $password `
          -SamAccountName $username `
          -DisplayName "$firstname $lastname" `
          -EmailAddress "$email" `
          -Description "$description" `
          -Path "$ou" `
          -Enabled $True `
          -GivenName "$firstname" `
          -Surname "$lastname" `
          -UserPrincipalName "$username@contosotest.com" `
          -PasswordNeverExpires $True `
          -PassThru
          
}

}
#endregion
          
                 