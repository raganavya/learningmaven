<#
.SYNOPSIS
ExportUsersFromADGroup_Okta.ps1 - Exports the user from the Security Group.

.DESCRIPTION 
This script export the users from the security groups in a csv format.

.OUTPUTS
The report is output to CSV file.

.EXAMPLE
.\ExportUsersFromADGroup_Okta.ps1

.EXAMPLE
.\ExportUsersFromADGroup_Okta.ps1 -Verbose

.LINK
https://stackoverflow.com/questions/52040689/extracting-ad-records-attributes-from-a-group-but-need-managers-email-address-a

.NOTES
Script provided by community members and re-factored by Jaspreet Singh to work according to our environment

Version history:
V1.00, 02/10/2019 - Initial version

#>

#...................................
# Variables
#...................................

$path = "c:\Temp\script-$((get-date).tostring('dd-MM-yyyy')).csv"
$SecurityGroup = 'dac-qlik-ctp'

#...................................
# Script
#...................................

# Get the AD group member properties from the security group
get-adgroupmember $SecurityGroup | get-aduser -properties emailaddress, title, Department, Name, GivenName, description | Select-Object userprincipalname, givenname, surname, emailaddress, description, department |
#Loop through the list of members
    ForEach-Object {
            new-object psobject -Property @{
                                             login = $_.userprincipalname #sAMAccountName
                                             firstName  = $_.givenname
                                             lastName   = $_.surname
                                             email      = $_.emailaddress
                                            #Company    = $_.company
                                             department = $_.department
                                             honorificPrefix = $_.description
                                             }
           } | Select-Object login, firstName, lastName, email,department, honorificPrefix |
           #Output the report to CSV
               Export-Csv $path -NoTypeInformation