Disclaimer: an Okta user deletion is a permanent process that cannot be reversed. Use these scripts at your own risk. All scripts are provided AS IS without warranty of any kind. Okta disclaims all implied warranties including, without limitation, any implied warranties of fitness for a particular purpose. We highly recommend testing scripts in a preview environment if possible.

For instructions on how to use this script, please visit https://support.okta.com/help/Documentation/Knowledge_Article/How-to-Perform-a-Bulk-Delete-of-Okta-Users-With-API
