﻿$SourceLogFiles =  'E:\sumologs\windows\*.csv'
$DestinationLogFiles = 'E:\sumologs\windows_qlik'

#Copy all files from Source to Destination Folder

Copy-Item -Path $SourceLogFiles -Destination $DestinationLogFiles -Force