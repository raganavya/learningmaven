﻿# Script to list the group members on the screen

$groupname = "npdac-qlik-hbc"

$users = Get-ADGroupMember -Identity $groupname | Where-Object {$_.objectclass -eq "user"}
foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | `
Where-Object {$_.enabled -eq $false}# Toggle True/False according to the requirement | `
select Name, SamAccountName, UserPrincipalName, Enabled  | Export-CSV C:\Work\qlik-hbc-user-groups-prod.csv

} 