﻿$Groups = Get-ADGroup -Properties * -Filter *
Foreach($G In $Groups)
{  
Get-ADGroup $G -Properties member | select Name, @{N='Count';E={$_.member.count}}  | export-csv C:\Work\test15.csv -append
}

# prd_ldap_openvpn
# dac-fileshare-users   + npdac-fileshare-users
# hdp_users
# dac-mysql
# dac-tableau
# dac-rstudio-users
# dac-rconnect-users
# dac-qlik


#prd_ldap_openvpn, dac-fileshare-users, npdac-fileshare-users, hdp_users, dac-mysql, dac-tableau, dac-rstudio-users, dac-rconnect-users, dac-qlik