﻿#Reference: https://superuser.com/questions/1267099/how-can-i-list-all-members-from-ad-group-showing-enable-and-disabled-users


$groupname = "npdac-mysql"
$users = Get-ADGroupMember -Identity $groupname | Where-Object {$_.objectclass -eq "user"}
foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | select Name, SamAccountName, UserPrincipalName, Enabled }


