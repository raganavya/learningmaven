
<#
.SYNOPSIS
Get-AllOktaUsers.ps1 - Exports the user from the Okta.

.DESCRIPTION 
This script export the users from the Okta in a csv format.

.OUTPUTS
The report is output to CSV file.

.EXAMPLE
Example: .\Get-AllOktaUsers.ps1 -org "tenant" -api_token "0000000000" -outfile "c:\scripts\groupname.csv"

.LINK
https://medium.com/@chrisneely/okta-api-series-part-1-list-group-members-9080d81225 

.NOTES
Requires PowerShell3.0 or later. This Script is authored by Chris Neely and re-factored to work according to our environment

Version history: None

#>
#requires -version 3.0

#...................................
# Parameter Block
#...................................

param(
 [Parameter(Mandatory=$true)]$org, # Your tentant prefix - Ex. tenant.okta.com
 [Parameter(Mandatory=$false)]$gid, # The group ID for the group you want to export - Ex. https://tenant-admin.okta.com/admin/group/00000000000000000000
 [Parameter(Mandatory=$true)]$api_token, # Your API Token. You can generate this from Admin - Security - API
 [Parameter(Mandatory=$true)]$outfile # The path and file name for the resulting CSV file
 )

 # Set the TLS version used by the PowerShell client to TLS 1.2.
#[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

### Define $allusers and $selectedUsers as empty arrays
$allusers = @()
$selectedUsers = @()
### Set $uri as the API URI for use in the loop
$uri = "https://$org.okta.com/api/v1/users"
### Use a while loop and get all users from Okta API
DO
{
$webrequest = Invoke-WebRequest -Headers @{"Authorization" = "SSWS $api_token"} -Method Get -Uri $uri
$link = $webrequest.Headers.Link.Split("<").Split(">") 
$uri = $link[3]
$json = $webrequest | ConvertFrom-Json
$allusers += $json
} while ($webrequest.Headers.Link.EndsWith('rel="next"'))
### Filter the results and remove any DEPROVISIONED users
$activeUsers = $allusers | Where-Object { $_.status -ne "DEPROVISIONED" }
### Select the user profile properties we want and export to CSV
$activeUsers | Select-Object -ExpandProperty profile | Select-Object -Property login, email, secondEmail, displayName, primaryPhone, mobilePhone, organization, department | Export-Csv -Path $outfile -NoTypeInformation
