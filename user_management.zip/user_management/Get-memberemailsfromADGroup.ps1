# Get the AD group member email addresses
Get-ADGroupMember -Identity "dac-qlik-prd-ctp– Claims & Payments (New)" -Recursive |
Get-ADUser -Properties Mail | Select-Object Name,Mail