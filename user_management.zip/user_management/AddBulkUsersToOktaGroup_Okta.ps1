<#
.SYNOPSIS
AddBulkUsersToOktaGroup_Okta.ps1 - Add the bulk users provided in the csv file to Okta Group.

.DESCRIPTION 
This script uploads bulk users provided in a csv format to an Okta Group. Prior to running this script you need to extract the users from the AD group in a csv format
and save it on desktop or on C drive. Also, you need to create a Group in Okta and get the Group ID from the Okta.

You need to generate a API token in okta to authenticate with okta


.OUTPUTS
The script output the file to the csv

.EXAMPLE
.\AddBulkUsersToOktaGroup_Okta.ps1

.EXAMPLE
.\AddBulkUsersToOktaGroup_Okta.ps1

.LINK
https://www.hackinginnovated.com/blog.php?post=201952%20&cat=Information%20Security
https://www.lieben.nu/liebensraum/2017/08/how-to-retrieve-all-okta-groups-including-their-members-using-powershell/ 

.NOTES
Script provided by community members and re-factored (By Jaspreet) with few changes to work according to our environment

Version history:
V1.00, 02/10/2019 - Initial version
V1.01, 21/10/2020 - Second Version

#>


# adding bulk users to Okta managed groups using Windows Powershell

# Create a function to select the csv file

Function SelectFile{
    Add-Type -AssemblyName System.Windows.Forms
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ InitialDirectory = [Environment]::GetFolderPath('Desktop') }
    $FileBrowser.filter = "CSV(*.csv)|*.csv"
    $null = $FileBrowser.ShowDialog()
    $FileBrowser.FileName
    }
    
Function get-path{
    $inputfilepath = SelectFile -initialdirectory ".\"
    $inputfilepath 
    }
             
    #If you notice here we have set our initialdirectory value to .\ so that it opens in our root directory.
    
        
    $path = get-path
    #Beginning to fetch the .csv file containing user in Column "NTID"
    $Users = Import-Csv $path
    
    $api_token = 'Enter API Token'#You can get your organization's Okta API key from Okta Admin Console. API key is required as part of your authenticator header to let you login with admin access.
    $group_id = '00g14i50hihPR06gq4x7' # Get Group ID from Okta Portal i.e. https://outlookjaspreetxsingh-admin.okta.com/admin/group/00g12hvd79SjMmnPR4x7 - The first numbers starting with 00 is Group ID
    $headers = @{
        'Accept'       = 'application/json'
        'Content-Type' = 'application/json'
        'Authorization'= 'SSWS '+$api_token
       #'Authorization' = $api_token
    }
    #return $headers
    
     
    foreach($user in $Users){
    try {
    $user = $user.login
    $user = Invoke-RestMethod -Uri https://outlookjaspreetxsingh-admin.okta.com/api/v1/users/$user -Method Get -Headers $headers
    $userId = $user.id
    
    $group = Invoke-RestMethod -Uri https://outlookjaspreetxsingh-admin.okta.com/api/v1/groups/$group_id/users/$userId -Method Put -Headers $headers
    Write-Host "Added user " + $user.profile.email + " to the $group"
    
    }
    
    catch {
        Write-Host "An error occurred:"
        Write-Host $_
    }
    #Store the information from this run into the array and output the results in the csv file
    [PSCustomObject]@{
        Status = $user.status
        Department = $user.profile.department
        FirstName = $user.profile.firstName
        LastName = $user.profile.lastName
        Login = $user.profile.login
        Email = $user.profile.email
        } | Export-Csv C:\Temp\ImportBulkUsers-Result.csv -notype -Append
    }
